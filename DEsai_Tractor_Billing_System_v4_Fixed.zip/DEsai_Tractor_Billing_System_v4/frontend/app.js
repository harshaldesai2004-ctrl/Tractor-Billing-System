// ===============================================
//  DATA STORE (works standalone without backend)
// ===============================================
const API_BASE = 'http://localhost:8080/api';
let useLocalData = false; // backend connected

let DB = {
  bills: [
    { id: 1, customerId: 1, tractorId: 1, service: 'Ploughing', hours: 8, rate: 350, amount: 2800, date: '2025-01-05', due: '2025-01-20', status: 'Paid', area: 4, notes: 'North field' },
    { id: 2, customerId: 2, tractorId: 2, service: 'Harvesting', hours: 12, rate: 400, amount: 4800, date: '2025-01-12', due: '2025-01-27', status: 'Paid', area: 6, notes: '' },
    { id: 3, customerId: 3, tractorId: 1, service: 'Sowing', hours: 5, rate: 300, amount: 1500, date: '2025-02-03', due: '2025-02-18', status: 'Pending', area: 3, notes: 'Wheat crop' },
    { id: 4, customerId: 1, tractorId: 3, service: 'Transport', hours: 3, rate: 450, amount: 1350, date: '2025-02-15', due: '2025-03-01', status: 'Paid', area: 0, notes: '' },
    { id: 5, customerId: 4, tractorId: 2, service: 'Harrowing', hours: 6, rate: 350, amount: 2100, date: '2025-03-08', due: '2025-03-23', status: 'Overdue', area: 5, notes: '' },
    { id: 6, customerId: 2, tractorId: 1, service: 'Rotavation', hours: 7, rate: 380, amount: 2660, date: '2025-03-18', due: '2025-04-02', status: 'Paid', area: 3.5, notes: '' },
    { id: 7, customerId: 5, tractorId: 3, service: 'Ploughing', hours: 10, rate: 350, amount: 3500, date: '2025-04-02', due: '2025-04-17', status: 'Pending', area: 7, notes: 'Deep plough' },
    { id: 8, customerId: 3, tractorId: 2, service: 'Harvesting', hours: 14, rate: 400, amount: 5600, date: '2025-04-20', due: '2025-05-05', status: 'Paid', area: 8, notes: '' },
    { id: 9, customerId: 6, tractorId: 1, service: 'Sowing', hours: 4, rate: 300, amount: 1200, date: '2025-05-10', due: '2025-05-25', status: 'Pending', area: 2, notes: '' },
    { id: 10, customerId: 4, tractorId: 3, service: 'Ploughing', hours: 9, rate: 350, amount: 3150, date: '2025-05-22', due: '2025-06-06', status: 'Overdue', area: 5.5, notes: 'Red soil' },
    { id: 11, customerId: 1, tractorId: 2, service: 'Transport', hours: 5, rate: 450, amount: 2250, date: '2025-06-05', due: '2025-06-20', status: 'Paid', area: 0, notes: '' },
    { id: 12, customerId: 5, tractorId: 1, service: 'Harrowing', hours: 8, rate: 350, amount: 2800, date: '2025-06-18', due: '2025-07-03', status: 'Paid', area: 4, notes: '' },
    { id: 13, customerId: 2, tractorId: 3, service: 'Rotavation', hours: 6, rate: 380, amount: 2280, date: '2025-07-08', due: '2025-07-23', status: 'Paid', area: 3, notes: '' },
    { id: 14, customerId: 6, tractorId: 2, service: 'Ploughing', hours: 11, rate: 350, amount: 3850, date: '2025-08-01', due: '2025-08-16', status: 'Pending', area: 6, notes: '' },
    { id: 15, customerId: 3, tractorId: 1, service: 'Harvesting', hours: 15, rate: 400, amount: 6000, date: '2025-08-25', due: '2025-09-09', status: 'Paid', area: 9, notes: 'Good yield' },
  ],
  tractors: [
    { id: 1, reg: 'GJ-05-AB-1234', brand: 'Mahindra', model: '575 DI', hp: 42, year: 2020, status: 'Active', owner: 'Raju Patel', rate: 350 },
    { id: 2, reg: 'GJ-05-CD-5678', brand: 'John Deere', model: '5310', hp: 55, year: 2022, status: 'Active', owner: 'Suresh Sharma', rate: 400 },
    { id: 3, reg: 'GJ-05-EF-9012', brand: 'Sonalika', model: 'DI 60', hp: 60, year: 2021, status: 'Maintenance', owner: 'Mukesh Verma', rate: 450 },
  ],
  customers: [
    { id: 1, name: 'Ramesh Patel', phone: '9876543210', village: 'Borsad', district: 'Anand', aadhar: '', land: 12 },
    { id: 2, name: 'Suresh Desai', phone: '9765432109', village: 'Khambhat', district: 'Anand', aadhar: '', land: 8 },
    { id: 3, name: 'Mahesh Shah', phone: '9654321098', village: 'Tarapur', district: 'Anand', aadhar: '', land: 15 },
    { id: 4, name: 'Naresh Joshi', phone: '9543210987', village: 'Petlad', district: 'Anand', aadhar: '', land: 6 },
    { id: 5, name: 'Dinesh Solanki', phone: '9432109876', village: 'Umreth', district: 'Anand', aadhar: '', land: 10 },
    { id: 6, name: 'Kamlesh Parmar', phone: '9321098765', village: 'Balasinor', district: 'Kheda', aadhar: '', land: 9 },
  ],
  acreRates: [
    { id: 1, service: 'Ploughing',   tractorType: 'Any',                  rate: 900,  minAcres: 1,   season: 'All Season', effectiveDate: '2025-01-01', status: 'Active',   discount: 0,  notes: 'Standard ploughing rate' },
    { id: 2, service: 'Harrowing',   tractorType: 'Any',                  rate: 750,  minAcres: 1,   season: 'All Season', effectiveDate: '2025-01-01', status: 'Active',   discount: 0,  notes: '' },
    { id: 3, service: 'Sowing',      tractorType: 'Small (up to 40 HP)',  rate: 600,  minAcres: 1,   season: 'Kharif',     effectiveDate: '2025-06-01', status: 'Active',   discount: 5,  notes: 'Kharif season rate' },
    { id: 4, service: 'Sowing',      tractorType: 'Small (up to 40 HP)',  rate: 550,  minAcres: 1,   season: 'Rabi',       effectiveDate: '2025-10-01', status: 'Active',   discount: 0,  notes: 'Rabi season rate' },
    { id: 5, service: 'Harvesting',  tractorType: 'Heavy (56+ HP)',       rate: 1200, minAcres: 2,   season: 'All Season', effectiveDate: '2025-01-01', status: 'Active',   discount: 10, notes: 'Bulk discount above 5 acres' },
    { id: 6, service: 'Rotavation',  tractorType: 'Medium (41-55 HP)',    rate: 850,  minAcres: 1,   season: 'All Season', effectiveDate: '2025-01-01', status: 'Active',   discount: 0,  notes: '' },
    { id: 7, service: 'Transport',   tractorType: 'Any',                  rate: 500,  minAcres: 0,   season: 'All Season', effectiveDate: '2025-01-01', status: 'Active',   discount: 0,  notes: 'Per trip rate' },
    { id: 8, service: 'Ploughing',   tractorType: 'Heavy (56+ HP)',       rate: 1100, minAcres: 3,   season: 'Kharif',     effectiveDate: '2025-06-01', status: 'Active',   discount: 5,  notes: 'Heavy tractor premium' },
  ],
  services: [
    { id: 1, name: 'Ploughing',   category: 'Field Preparation', rateHr: 350, rateAcre: 900,  duration: 2.5, status: 'Active',   icon: '🌾', equipment: 'Mouldboard Plough', desc: 'Deep turning of soil to prepare for planting, improves soil aeration.' },
    { id: 2, name: 'Harrowing',   category: 'Field Preparation', rateHr: 320, rateAcre: 750,  duration: 2.0, status: 'Active',   icon: '🔧', equipment: 'Disc Harrow',       desc: 'Breaking up soil clods and smoothing the surface after ploughing.' },
    { id: 3, name: 'Sowing',      category: 'Planting',          rateHr: 300, rateAcre: 600,  duration: 1.5, status: 'Active',   icon: '🌱', equipment: 'Seed Drill',        desc: 'Mechanical planting of seeds at uniform depth and spacing.' },
    { id: 4, name: 'Harvesting',  category: 'Harvesting',        rateHr: 400, rateAcre: 1200, duration: 3.0, status: 'Active',   icon: '🌻', equipment: 'Combine Harvester', desc: 'Cutting, threshing and cleaning of mature crops in one pass.' },
    { id: 5, name: 'Transport',   category: 'Transport',         rateHr: 450, rateAcre: 500,  duration: 1.0, status: 'Active',   icon: '🚛', equipment: 'Tractor + Trolley', desc: 'Moving farm produce, inputs or equipment between locations.' },
    { id: 6, name: 'Rotavation',  category: 'Field Preparation', rateHr: 380, rateAcre: 850,  duration: 2.0, status: 'Active',   icon: '⚙️', equipment: 'Rotavator',         desc: 'Fine tilling using rotating blades, mixes crop residue into soil.' },
    { id: 7, name: 'Other',       category: 'Other',             rateHr: 350, rateAcre: 700,  duration: 2.0, status: 'Active',   icon: '🔩', equipment: 'As Required',       desc: 'Miscellaneous farm services as requested by the customer.' },
  ],
  nextBillId: 16,
  nextTractorId: 4,
  nextCustomerId: 7,
  nextAcreRateId: 9,
  nextServiceId: 8,
};

// ===============================================
//  API LAYER
// ===============================================
async function apiGet(endpoint) {
  if (useLocalData) return localGet(endpoint);
  try {
    const r = await fetch(API_BASE + endpoint);
    return r.json();
  } catch(e) { return localGet(endpoint); }
}

async function apiPost(endpoint, data) {
  if (useLocalData) return localPost(endpoint, data);
  try {
    const r = await fetch(API_BASE + endpoint, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) });
    return r.json();
  } catch(e) { return localPost(endpoint, data); }
}

async function apiPut(endpoint, data) {
  if (useLocalData) return localPut(endpoint, data);
  try {
    const r = await fetch(API_BASE + endpoint, { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) });
    return r.json();
  } catch(e) { return localPut(endpoint, data); }
}

async function apiDelete(endpoint) {
  if (useLocalData) return localDelete(endpoint);
  try {
    const r = await fetch(API_BASE + endpoint, { method:'DELETE' });
    return r.json();
  } catch(e) { return localDelete(endpoint); }
}

// Local CRUD
function localGet(ep) {
  if (ep === '/bills') return [...DB.bills];
  if (ep === '/tractors') return [...DB.tractors];
  if (ep === '/customers') return [...DB.customers];
  if (ep === '/acrerates') return [...DB.acreRates];
  if (ep === '/services') return [...DB.services];
  if (ep.startsWith('/bills/')) return DB.bills.find(b=>b.id==ep.split('/').pop());
  if (ep.startsWith('/tractors/')) return DB.tractors.find(t=>t.id==ep.split('/').pop());
  if (ep.startsWith('/customers/')) return DB.customers.find(c=>c.id==ep.split('/').pop());
  if (ep.startsWith('/acrerates/')) return DB.acreRates.find(r=>r.id==ep.split('/').pop());
  if (ep.startsWith('/services/')) return DB.services.find(s=>s.id==ep.split('/').pop());
}
function localPost(ep, data) {
  if (ep === '/bills') { data.id = DB.nextBillId++; DB.bills.push(data); return data; }
  if (ep === '/tractors') { data.id = DB.nextTractorId++; DB.tractors.push(data); return data; }
  if (ep === '/customers') { data.id = DB.nextCustomerId++; DB.customers.push(data); return data; }
  if (ep === '/acrerates') { data.id = DB.nextAcreRateId++; DB.acreRates.push(data); return data; }
  if (ep === '/services') { data.id = DB.nextServiceId++; DB.services.push(data); return data; }
}
function localPut(ep, data) {
  const [, type, id] = ep.split('/');
  const arr = DB[type];
  const idx = arr.findIndex(x=>x.id==id);
  if (idx>-1) { arr[idx] = {...arr[idx], ...data}; return arr[idx]; }
}
function localDelete(ep) {
  const [, type, id] = ep.split('/');
  const arr = DB[type];
  const idx = arr.findIndex(x=>x.id==id);
  if (idx>-1) arr.splice(idx,1);
  return { deleted: true };
}

// ===============================================
//  NAVIGATION
// ===============================================
const PAGE_TITLES = { dashboard:'Dashboard', billing:'Billing', tractors:'Tractors', customers:'Customers', reports:'Reports', pdf:'PDF Invoices' };

function navigate(page, el) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  // highlight the clicked nav item (el may be undefined if called programmatically)
  if (el) el.classList.add('active');
  else {
    // find nav item by text match
    document.querySelectorAll('.nav-item').forEach(n => {
      if (n.textContent.toLowerCase().includes(page)) n.classList.add('active');
    });
  }
  document.getElementById('page-' + page).classList.add('active');
  document.getElementById('topbarTitle').textContent = PAGE_TITLES[page].toUpperCase();
  if (page === 'dashboard') loadDashboard();
  if (page === 'billing') loadBills();
  if (page === 'tractors') loadTractors();
  if (page === 'customers') loadCustomers();
  if (page === 'reports') loadReports();
  if (page === 'pdf') loadPdfPage();
}

// ===============================================
//  DASHBOARD
// ===============================================
let charts = {};

async function loadDashboard() {
  const bills = await apiGet('/bills');
  const tractors = await apiGet('/tractors');

  const paid = bills.filter(b=>b.status==='Paid');
  const pending = bills.filter(b=>b.status==='Pending');
  const overdue = bills.filter(b=>b.status==='Overdue');
  const revenue = paid.reduce((s,b)=>s+b.amount,0);
  const outstanding = overdue.reduce((s,b)=>s+Math.max(0,(b.amount||0)-(b.paidAmount||0)),0);
  const active = tractors.filter(t=>t.status==='Active').length;

  const pendingAmt = pending.reduce((s,b)=>s+Math.max(0,(b.amount||0)-(b.paidAmount||0)),0);
  document.getElementById('stat-revenue').textContent = 'Rs.' + revenue.toLocaleString('en-IN');
  document.getElementById('stat-pending').textContent = pending.length;
  document.getElementById('stat-tractors').textContent = active;
  document.getElementById('stat-overdue').textContent = overdue.length;
  document.getElementById('stat-ov-badge').textContent = 'Rs.' + outstanding.toLocaleString('en-IN');
  const pendBadge = document.getElementById('stat-pending-badge');
  if (pendBadge) pendBadge.textContent = 'Rs.' + pendingAmt.toLocaleString('en-IN') + ' pending';

  drawRevenueChart(bills);
  drawStatusChart(paid.length, pending.length, overdue.length);
  drawServiceChart(bills);
  drawCustomerChart(bills);
}

function monthlyRevenue(bills) {
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const data = new Array(12).fill(0);
  bills.filter(b=>b.status==='Paid').forEach(b => {
    const m = new Date(b.date).getMonth();
    data[m] += b.amount;
  });
  return { labels: months, data };
}

function drawRevenueChart(bills) {
  const { labels, data } = monthlyRevenue(bills);
  const ctx = document.getElementById('revenueChart').getContext('2d');
  if (charts.revenue) charts.revenue.destroy();
  charts.revenue = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Revenue (Rs.)',
        data,
        backgroundColor: 'rgba(46,125,50,0.3)',
        borderColor: '#2e7d32',
        borderWidth: 2,
        borderRadius: 4,
      }]
    },
    options: chartOpts()
  });
}

function drawStatusChart(paid, pending, overdue) {
  const ctx = document.getElementById('statusChart').getContext('2d');
  if (charts.status) charts.status.destroy();
  charts.status = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Paid', 'Pending', 'Overdue'],
      datasets: [{ data: [paid, pending, overdue], backgroundColor: ['#388e3c','#e65100','#c62828'], borderWidth: 0 }]
    },
    options: { ...chartOpts(true), cutout: '65%' }
  });
}

function drawServiceChart(bills) {
  const counts = {};
  bills.forEach(b => { counts[b.service] = (counts[b.service]||0) + b.amount; });
  const ctx = document.getElementById('serviceChart').getContext('2d');
  if (charts.service) charts.service.destroy();
  charts.service = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: Object.keys(counts),
      datasets: [{ label: 'Revenue', data: Object.values(counts), backgroundColor: ['#388e3c','#e65100','#1565c0','#c62828','#f9a825','#6a1b9a','#00838f'], borderRadius: 4 }]
    },
    options: { ...chartOpts(), indexAxis: 'y' }
  });
}

function drawCustomerChart(bills) {
  const rev = {};
  bills.filter(b=>b.status==='Paid').forEach(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId);
    if (cust) rev[cust.name] = (rev[cust.name]||0) + b.amount;
  });
  const sorted = Object.entries(rev).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const ctx = document.getElementById('customerChart').getContext('2d');
  if (charts.customer) charts.customer.destroy();
  charts.customer = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: sorted.map(x=>x[0].split(' ')[0]),
      datasets: [{ label: 'Revenue', data: sorted.map(x=>x[1]), backgroundColor: 'rgba(21,101,192,0.15)', borderColor: '#1565c0', borderWidth: 2, borderRadius: 4 }]
    },
    options: chartOpts()
  });
}

function chartOpts(noScales) {
  const opts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { labels: { color: '#5d4037', font: { family: 'DM Sans', size: 11 } } } },
  };
  if (!noScales) {
    opts.scales = {
      x: { ticks: { color: '#8d6e63', font: { family: 'DM Sans' } }, grid: { color: '#d6cfc6' } },
      y: { ticks: { color: '#8d6e63', font: { family: 'DM Sans' } }, grid: { color: '#d6cfc6' } }
    };
  }
  return opts;
}

// ===============================================
//  BILLING
// ===============================================
let allBills = [];

async function loadBills() {
  allBills = await apiGet('/bills');
  // Refresh DB caches so filters see latest customers/tractors
  DB.customers = await apiGet('/customers');
  DB.tractors = await apiGet('/tractors');
  populateMonthFilter();
  renderBills(allBills);
  populateFormDropdowns();
}

function populateMonthFilter() {
  const sel = document.getElementById('billMonthFilter');
  const months = [...new Set(allBills.map(b => b.date.substring(0,7)))].sort().reverse();
  sel.innerHTML = '<option value="">All Months</option>' + months.map(m=>`<option value="${m}">${m}</option>`).join('');
}

function filterBills() {
  const q = document.getElementById('billSearch').value.toLowerCase();
  const st = document.getElementById('billStatusFilter').value;
  const mo = document.getElementById('billMonthFilter').value;
  let filtered = allBills.filter(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId);
    const trac = DB.tractors.find(t=>t.id===b.tractorId);
    const text = `${b.id} ${cust?.name||''} ${trac?.reg||''} ${b.service}`.toLowerCase();
    return text.includes(q) && (!st || b.status===st) && (!mo || b.date.startsWith(mo));
  });
  renderBills(filtered);
}

function renderBills(bills) {
  const tbody = document.getElementById('billTableBody');
  if (!bills.length) {
    tbody.innerHTML = '<tr><td colspan="12" class="loading">No bills found.</td></tr>';
    document.getElementById('billTotal').textContent = 'Rs.0';
    document.getElementById('billCount').textContent = '0 records';
    return;
  }
  tbody.innerHTML = bills.map(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId);
    const trac = DB.tractors.find(t=>t.id===b.tractorId);
    const badges = { Paid:'badge-paid', Pending:'badge-pending', Overdue:'badge-overdue' };
    const paidAmt = b.paidAmount || 0;
    const pendingAmt = Math.max(0, (b.amount || 0) - paidAmt);
    const paidCell = paidAmt > 0
      ? `<span style="color:#2e7d32;font-weight:700;">Rs.${paidAmt.toLocaleString('en-IN')}</span>`
      : `<span style="color:#aaa;">—</span>`;
    const pendingCell = (b.status !== 'Paid' && pendingAmt > 0)
      ? `<span style="color:#e65100;font-weight:700;">Rs.${pendingAmt.toLocaleString('en-IN')}</span>`
      : `<span style="color:#aaa;">—</span>`;
    return `<tr>
      <td>#${String(b.id).padStart(4,'0')}</td>
      <td style="font-family:'DM Sans'">${cust?.name||'Unknown'}</td>
      <td>${trac?.reg||'Unknown'}</td>
      <td>${b.service}</td>
      <td>${b.hours}h</td>
      <td>${b.acrerate ? 'Rs.'+b.acrerate.toLocaleString('en-IN') : '-'}</td>
      <td style="font-weight:600;">Rs.${b.amount.toLocaleString('en-IN')}</td>
      <td>${paidCell}</td>
      <td>${pendingCell}</td>
      <td>${b.date}</td>
      <td><span class="badge ${badges[b.status]}">${b.status}</span></td>
      <td>
        <div class="action-btns">
          <button class="btn btn-ghost btn-sm" title="Print Invoice" onclick="printBillInvoice(${b.id})">🖨️</button>
          <button class="btn btn-ghost btn-sm" onclick="editBill(${b.id})">✏️</button>
          <button class="btn btn-danger btn-sm" onclick="deleteBill(${b.id})">🗑️</button>
        </div>
      </td>
    </tr>`;
  }).join('');
  const total = bills.reduce((s,b)=>s+b.amount,0);
  document.getElementById('billTotal').textContent = 'Rs.' + total.toLocaleString('en-IN');
  document.getElementById('billCount').textContent = `${bills.length} records`;
}

async function populateFormDropdowns() {
  const custs = await apiGet('/customers');
  const tracs = await apiGet('/tractors');
  document.getElementById('f-customer').innerHTML = custs.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
  document.getElementById('f-tractor').innerHTML = tracs.map(t=>`<option value="${t.id}">${t.reg} - ${t.brand}</option>`).join('');
}

function calcAmount() {
  const h = parseFloat(document.getElementById('f-hours').value) || 0;
  const r = parseFloat(document.getElementById('f-rate').value) || 0;
  const area = parseFloat(document.getElementById('f-area').value) || 0;
  const ar = parseFloat(document.getElementById('f-acrerate').value) || 0;
  const hourAmount = h * r;
  const acreAmount = area * ar;
  const total = (hourAmount + acreAmount) || 0;
  document.getElementById('f-amount').value = total || '';
  // sync payment calculator total display
  const fmtAmt = v => Number(v).toLocaleString('en-IN', {minimumFractionDigits:2});
  const calcTotal = document.getElementById('calc-total');
  if (calcTotal) calcTotal.textContent = 'Rs.' + fmtAmt(total);
  calcPendingBalance();
}

function calcPendingBalance() {
  const fmtAmt = v => Number(v).toLocaleString('en-IN', {minimumFractionDigits:2});
  const total   = parseFloat(document.getElementById('f-amount').value) || 0;
  const paid    = parseFloat(document.getElementById('f-paid-amount').value) || 0;
  const balance = Math.max(0, total - paid);

  // Update total display
  const calcTotal = document.getElementById('calc-total');
  if (calcTotal) calcTotal.textContent = 'Rs.' + fmtAmt(total);

  // Update balance
  const balEl = document.getElementById('calc-balance');
  if (balEl) {
    balEl.textContent = 'Rs.' + fmtAmt(balance);
    balEl.style.color = balance === 0 ? '#2e7d32' : '#e65100';
    balEl.style.background = balance === 0 ? '#e8f5e9' : '#fff3e0';
    balEl.style.borderColor = balance === 0 ? '#c8e6c9' : '#ffe0b2';
  }

  // Compute auto-status
  const badgeEl = document.getElementById('calc-status-badge');
  if (badgeEl) {
    let autoStatus = '', bg = '', color = '';
    if (paid <= 0)                        { autoStatus = 'Pending';  bg = '#fff3e0'; color = '#e65100'; }
    else if (balance === 0)               { autoStatus = 'Paid';     bg = '#e8f5e9'; color = '#2e7d32'; }
    else                                  { autoStatus = 'Partial';  bg = '#e3f2fd'; color = '#1565c0'; }
    badgeEl.textContent = autoStatus || '—';
    badgeEl.style.background = bg;
    badgeEl.style.color = color;
  }
}

function applyPayment() {
  const total   = parseFloat(document.getElementById('f-amount').value) || 0;
  const paid    = parseFloat(document.getElementById('f-paid-amount').value) || 0;
  const balance = Math.max(0, total - paid);
  const statusSel = document.getElementById('f-status');
  if (paid <= 0) {
    statusSel.value = 'Pending';
    showToast('Status set to Pending — no payment entered.', 'success');
  } else if (balance === 0) {
    statusSel.value = 'Paid';
    showToast('✅ Full payment applied — Status set to Paid!', 'success');
  } else {
    statusSel.value = 'Pending';
    const fmtAmt = v => Number(v).toLocaleString('en-IN', {minimumFractionDigits:2});
    showToast(`⏳ Partial Rs.${fmtAmt(paid)} paid — Rs.${fmtAmt(balance)} remaining. Status: Pending.`, 'success');
  }
}

function payFull() {
  const total = parseFloat(document.getElementById('f-amount').value) || 0;
  if (!total) { showToast('Please enter the bill amount first.', 'error'); return; }
  document.getElementById('f-paid-amount').value = total;
  calcPendingBalance();
  document.getElementById('f-status').value = 'Paid';
  showToast('💯 Full amount set — Status set to Paid!', 'success');
}

function clearPayment() {
  document.getElementById('f-paid-amount').value = '';
  calcPendingBalance();
}

let editingBillId = null;

function openAddModal() {
  editingBillId = null;
  document.getElementById('billModalTitle').textContent = 'NEW BILL';
  clearForm(['f-customer','f-tractor','f-service','f-hours','f-rate','f-amount','f-date','f-due','f-status','f-area','f-acrerate','f-notes','f-paid-amount']);
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('f-date').value = today;
  const due = new Date(); due.setDate(due.getDate()+15);
  document.getElementById('f-due').value = due.toISOString().split('T')[0];
  // Reset calculator display
  const calcTotal = document.getElementById('calc-total');
  if (calcTotal) calcTotal.textContent = 'Rs.0.00';
  calcPendingBalance();
  populateFormDropdowns();
  openModal('billModal');
}

async function editBill(id) {
  editingBillId = id;
  const b = await apiGet('/bills/' + id);
  document.getElementById('billModalTitle').textContent = 'EDIT BILL';
  await populateFormDropdowns();
  setFormVal('f-customer', b.customerId);
  setFormVal('f-tractor', b.tractorId);
  setFormVal('f-service', b.service);
  setFormVal('f-hours', b.hours);
  setFormVal('f-rate', b.rate);
  setFormVal('f-amount', b.amount);
  setFormVal('f-date', b.date);
  setFormVal('f-due', b.due);
  setFormVal('f-status', b.status);
  setFormVal('f-area', b.area);
  setFormVal('f-acrerate', b.acrerate);
  setFormVal('f-notes', b.notes);
  // Populate paid amount from saved bill data
  document.getElementById('f-paid-amount').value = b.paidAmount || '';
  const fmtAmt = v => Number(v).toLocaleString('en-IN', {minimumFractionDigits:2});
  const calcTotal = document.getElementById('calc-total');
  if (calcTotal) calcTotal.textContent = 'Rs.' + fmtAmt(b.amount || 0);
  calcPendingBalance();
  openModal('billModal');
}

async function saveBill() {
  const data = {
    customerId: parseInt(document.getElementById('f-customer').value),
    tractorId: parseInt(document.getElementById('f-tractor').value),
    service: document.getElementById('f-service').value,
    hours: parseFloat(document.getElementById('f-hours').value) || 0,
    rate: parseFloat(document.getElementById('f-rate').value) || 0,
    amount: parseFloat(document.getElementById('f-amount').value) || 0,
    paidAmount: parseFloat(document.getElementById('f-paid-amount').value) || 0,
    date: document.getElementById('f-date').value,
    due: document.getElementById('f-due').value,
    status: document.getElementById('f-status').value,
    area: parseFloat(document.getElementById('f-area').value) || 0,
    acrerate: parseFloat(document.getElementById('f-acrerate').value) || 0,
    notes: document.getElementById('f-notes').value,
  };
  if (!data.customerId || !data.tractorId || !data.date || !data.amount) { showToast('Please fill all required fields (Customer, Tractor, Date, Amount).','error'); return; }
  if (editingBillId) {
    await apiPut('/bills/' + editingBillId, data);
    showToast('Bill updated successfully!', 'success');
  } else {
    await apiPost('/bills', data);
    showToast('Bill created successfully!', 'success');
  }
  closeModal('billModal');
  await loadBills();
  // Only reload PDF page if it's currently visible
  if (document.getElementById('page-pdf').classList.contains('active')) await loadPdfPage();
  loadDashboard();
}

async function deleteBill(id) {
  if (!confirm('Delete this bill?')) return;
  await apiDelete('/bills/' + id);
  showToast('Bill deleted.', 'success');
  await loadBills();
  if (document.getElementById('page-pdf').classList.contains('active')) await loadPdfPage();
  loadDashboard();
}

// ===============================================
//  TRACTORS
// ===============================================
let editingTractorId = null;

async function loadTractors() {
  const tractors = await apiGet('/tractors');
  const grid = document.getElementById('tractorGrid');
  const statusClass = { Active:'status-active', Maintenance:'status-maintenance', Idle:'status-idle' };
  grid.innerHTML = tractors.map(t => `
    <div class="tractor-card">
      <div class="tractor-icon">🚜</div>
      <div class="tractor-reg">${t.reg}</div>
      <div class="tractor-info">
        ${t.brand} ${t.model}<br>
        ${t.hp} HP . ${t.year}<br>
        Owner: ${t.owner}<br>
        Rate: Rs.${t.rate}/hr
      </div>
      <span class="tractor-status ${statusClass[t.status]}">${t.status}</span>
      <div class="action-btns" style="margin-top:12px">
        <button class="btn btn-ghost btn-sm" onclick="editTractor(${t.id})">✏️ Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteTractor(${t.id})">🗑️</button>
      </div>
    </div>
  `).join('');
}

function openTractorModal() {
  editingTractorId = null;
  document.getElementById('tractorModalTitle').textContent = 'ADD TRACTOR';
  clearForm(['t-reg','t-brand','t-model','t-hp','t-year','t-status','t-owner','t-rate']);
  openModal('tractorModal');
}

async function editTractor(id) {
  editingTractorId = id;
  const t = await apiGet('/tractors/' + id);
  document.getElementById('tractorModalTitle').textContent = 'EDIT TRACTOR';
  setFormVal('t-reg', t.reg);
  setFormVal('t-brand', t.brand);
  setFormVal('t-model', t.model);
  setFormVal('t-hp', t.hp);
  setFormVal('t-year', t.year);
  setFormVal('t-status', t.status);
  setFormVal('t-owner', t.owner);
  setFormVal('t-rate', t.rate);
  openModal('tractorModal');
}

async function saveTractor() {
  const data = {
    reg: document.getElementById('t-reg').value,
    brand: document.getElementById('t-brand').value,
    model: document.getElementById('t-model').value,
    hp: parseInt(document.getElementById('t-hp').value)||0,
    year: parseInt(document.getElementById('t-year').value)||2020,
    status: document.getElementById('t-status').value,
    owner: document.getElementById('t-owner').value,
    rate: parseInt(document.getElementById('t-rate').value)||0,
  };
  if (!data.reg) { showToast('Registration number required.','error'); return; }
  if (editingTractorId) {
    await apiPut('/tractors/' + editingTractorId, data);
    showToast('Tractor updated!','success');
  } else {
    await apiPost('/tractors', data);
    showToast('Tractor added!','success');
  }
  closeModal('tractorModal');
  await loadTractors();
  await loadBills(); // refresh bills since tractor reg is shown there
}

async function deleteTractor(id) {
  if (!confirm('Delete this tractor?')) return;
  await apiDelete('/tractors/' + id);
  showToast('Tractor deleted.','success');
  loadTractors();
}

// ===============================================
//  CUSTOMERS
// ===============================================
let allCustomers = [];
let editingCustomerId = null;

async function loadCustomers() {
  allCustomers = await apiGet('/customers');
  DB.customers = allCustomers; // keep DB in sync
  renderCustomers(allCustomers);
}

function filterCustomers() {
  const q = document.getElementById('custSearch').value.toLowerCase();
  renderCustomers(allCustomers.filter(c => `${c.name} ${c.phone} ${c.village}`.toLowerCase().includes(q)));
}

function renderCustomers(custs) {
  const bills = DB.bills;
  const tbody = document.getElementById('customerTableBody');
  tbody.innerHTML = custs.map(c => {
    const cb = bills.filter(b=>b.customerId===c.id);
    const paid = cb.filter(b=>b.status==='Paid').reduce((s,b)=>s+b.amount,0);
    return `<tr>
      <td>#${c.id}</td>
      <td style="font-family:'DM Sans';font-weight:600">${c.name}</td>
      <td>${c.phone}</td>
      <td>${c.village}, ${c.district}</td>
      <td>${cb.length}</td>
      <td>Rs.${paid.toLocaleString('en-IN')}</td>
      <td>
        <div class="action-btns">
          <button class="btn btn-ghost btn-sm" onclick="editCustomer(${c.id})">✏️</button>
          <button class="btn btn-danger btn-sm" onclick="deleteCustomer(${c.id})">🗑️</button>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function openCustomerModal() {
  editingCustomerId = null;
  document.getElementById('customerModalTitle').textContent = 'ADD CUSTOMER';
  clearForm(['c-name','c-phone','c-village','c-district','c-aadhar','c-land']);
  openModal('customerModal');
}

async function editCustomer(id) {
  editingCustomerId = id;
  const c = await apiGet('/customers/' + id);
  document.getElementById('customerModalTitle').textContent = 'EDIT CUSTOMER';
  setFormVal('c-name', c.name);
  setFormVal('c-phone', c.phone);
  setFormVal('c-village', c.village);
  setFormVal('c-district', c.district);
  setFormVal('c-aadhar', c.aadhar);
  setFormVal('c-land', c.land);
  openModal('customerModal');
}

async function saveCustomer() {
  const data = {
    name: document.getElementById('c-name').value,
    phone: document.getElementById('c-phone').value,
    village: document.getElementById('c-village').value,
    district: document.getElementById('c-district').value,
    aadhar: document.getElementById('c-aadhar').value,
    land: parseFloat(document.getElementById('c-land').value)||0,
  };
  if (!data.name) { showToast('Name required.','error'); return; }
  if (editingCustomerId) {
    await apiPut('/customers/' + editingCustomerId, data);
    showToast('Customer updated!','success');
  } else {
    await apiPost('/customers', data);
    showToast('Customer added!','success');
  }
  closeModal('customerModal');
  await loadCustomers();
  await loadBills(); // refresh bills since customer names are displayed there
}

async function deleteCustomer(id) {
  if (!confirm('Delete this customer?')) return;
  await apiDelete('/customers/' + id);
  showToast('Customer deleted.','success');
  loadCustomers();
}

// ===============================================
//  REPORTS
// ===============================================
async function loadReports() {
  const bills = await apiGet('/bills');
  DB.bills = bills;
  const tractors = await apiGet('/tractors');
  DB.tractors = tractors;
  const customers = await apiGet('/customers');
  DB.customers = customers;

  // Set today's date as default for daily income date picker
  const dailyDateInput = document.getElementById('dailyIncomeDate');
  if (dailyDateInput && !dailyDateInput.value) {
    dailyDateInput.value = new Date().toISOString().split('T')[0];
  }

  // Quarterly chart
  const quarterly = [0,0,0,0];
  bills.filter(b=>b.status==='Paid').forEach(b => {
    const m = new Date(b.date).getMonth();
    quarterly[Math.floor(m/3)] += b.amount;
  });
  const ctxQ = document.getElementById('quarterlyChart').getContext('2d');
  if (charts.quarterly) charts.quarterly.destroy();
  charts.quarterly = new Chart(ctxQ, {
    type: 'line',
    data: {
      labels: ['Q1 (Jan-Mar)','Q2 (Apr-Jun)','Q3 (Jul-Sep)','Q4 (Oct-Dec)'],
      datasets: [{ label: 'Revenue', data: quarterly, borderColor: '#2e7d32', backgroundColor: 'rgba(46,125,50,0.1)', fill: true, tension: 0.4, pointRadius: 6, pointBackgroundColor: '#2e7d32' }]
    },
    options: chartOpts()
  });

  // Utilization chart
  const tractorHours = {};
  bills.forEach(b => {
    const t = tractors.find(x=>x.id===b.tractorId);
    if (t) tractorHours[t.reg] = (tractorHours[t.reg]||0) + b.hours;
  });
  const ctxU = document.getElementById('utilizationChart').getContext('2d');
  if (charts.util) charts.util.destroy();
  charts.util = new Chart(ctxU, {
    type: 'polarArea',
    data: {
      labels: Object.keys(tractorHours),
      datasets: [{ data: Object.values(tractorHours), backgroundColor: ['rgba(56,142,60,0.7)','rgba(21,101,192,0.7)','rgba(230,81,0,0.7)'] }]
    },
    options: { ...chartOpts(true) }
  });

  // Monthly table
  const monthly = {};
  bills.forEach(b => {
    const mo = b.date.substring(0,7);
    if (!monthly[mo]) monthly[mo] = { bills:0, revenue:0, pending:0 };
    monthly[mo].bills++;
    if (b.status==='Paid') monthly[mo].revenue += (b.paidAmount || b.amount || 0);
    if (b.status!=='Paid') monthly[mo].pending += Math.max(0, (b.amount||0) - (b.paidAmount||0));
  });
  const tbody = document.getElementById('reportTableBody');
  tbody.innerHTML = Object.entries(monthly).sort((a,b)=>b[0]<a[0]?-1:1).map(([mo,d])=>{
    const total = d.revenue + d.pending;
    const rate = total>0 ? Math.round(d.revenue/total*100) : 0;
    return `<tr>
      <td>${mo}</td>
      <td>${d.bills}</td>
      <td>Rs.${d.revenue.toLocaleString('en-IN')}</td>
      <td>Rs.${d.pending.toLocaleString('en-IN')}</td>
      <td><span class="badge ${rate>70?'badge-paid':'badge-pending'}">${rate}%</span></td>
    </tr>`;
  }).join('');
}

function exportCSV() {
  const bills = DB.bills;
  const header = ['Bill#','Customer','Tractor','Service','Hours','Rate','Amount','Date','Due','Status','Area','Notes'];
  const rows = bills.map(b => {
    const c = DB.customers.find(x=>x.id===b.customerId);
    const t = DB.tractors.find(x=>x.id===b.tractorId);
    return [b.id, c?.name||'', t?.reg||'', b.service, b.hours, b.rate, b.amount, b.date, b.due, b.status, b.area, b.notes];
  });
  const csv = [header, ...rows].map(r=>r.join(',')).join('\n');
  const a = document.createElement('a');
  a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  a.download = 'tractor-bills.csv';
  a.click();
  showToast('CSV exported!', 'success');
}

// ===============================================
//  PDF INVOICE SYSTEM
// ===============================================
let allPdfBills = [];
let currentPdfBillId = null;

async function loadPdfPage() {
  allPdfBills = await apiGet('/bills');
  DB.customers = await apiGet('/customers');
  DB.tractors = await apiGet('/tractors');
  populatePdfMonthFilter();
  renderPdfTable(allPdfBills);
}

function populatePdfMonthFilter() {
  const sel = document.getElementById('pdfMonthFilter');
  const months = [...new Set(allPdfBills.map(b => b.date.substring(0,7)))].sort().reverse();
  sel.innerHTML = '<option value="">All Months</option>' + months.map(m=>`<option value="${m}">${m}</option>`).join('');
}

function filterPdfBills() {
  const q  = document.getElementById('pdfSearch').value.toLowerCase();
  const st = document.getElementById('pdfStatusFilter').value;
  const mo = document.getElementById('pdfMonthFilter').value;
  const filtered = allPdfBills.filter(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId);
    const trac = DB.tractors.find(t=>t.id===b.tractorId);
    const text = `${b.id} ${cust?.name||''} ${trac?.reg||''} ${b.service}`.toLowerCase();
    return text.includes(q) && (!st || b.status===st) && (!mo || b.date.startsWith(mo));
  });
  renderPdfTable(filtered);
}

function renderPdfTable(bills) {
  const tbody = document.getElementById('pdfTableBody');
  if (!bills.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="loading">No bills found.</td></tr>';
    document.getElementById('pdfTotal').textContent = 'Rs.0';
    document.getElementById('pdfPending').textContent = 'Rs.0';
    document.getElementById('pdfCount').textContent = '0 records';
    return;
  }
  const badges = { Paid:'badge-paid', Pending:'badge-pending', Overdue:'badge-overdue' };
  tbody.innerHTML = bills.map(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId);
    const trac = DB.tractors.find(t=>t.id===b.tractorId);
    return `<tr>
      <td>#${String(b.id).padStart(4,'0')}</td>
      <td>${cust?.name||'Unknown'}</td>
      <td>${trac?.reg||'Unknown'}</td>
      <td>${b.service}</td>
      <td>Rs.${b.amount.toLocaleString('en-IN')}</td>
      <td>${b.date}</td>
      <td><span class="badge ${badges[b.status]}">${b.status}</span></td>
      <td>
        <div class="action-btns">
          <button class="btn btn-ghost btn-sm" title="Preview Invoice" onclick="previewInvoice(${b.id})">👁️</button>
          <button class="btn btn-primary btn-sm" title="Print Invoice" onclick="printBillInvoice(${b.id})">🖨️ Print</button>
        </div>
      </td>
    </tr>`;
  }).join('');
  const total = bills.reduce((s,b)=>s+b.amount,0);
  const pending = bills.filter(b=>b.status==='Pending').reduce((s,b)=>s+Math.max(0,(b.amount||0)-(b.paidAmount||0)),0);
  document.getElementById('pdfTotal').textContent = 'Rs.' + total.toLocaleString('en-IN');
  document.getElementById('pdfPending').textContent = 'Rs.' + pending.toLocaleString('en-IN');
  document.getElementById('pdfCount').textContent = `${bills.length} records`;
}

/** Build a fully self-contained invoice HTML string from local data (works in demo mode) */
function buildLocalInvoiceHtml(billId, autoPrint = false) {
  const bill = DB.bills.find(b => b.id === billId);
  if (!bill) return '<p>Bill not found.</p>';
  const cust = DB.customers.find(c => c.id === bill.customerId) || {};
  const trac = DB.tractors.find(t => t.id === bill.tractorId) || {};

  const fmt = d => d ? new Date(d).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'}) : '-';
  const statusColors = { Paid:'#2e7d32', Pending:'#e65100', Overdue:'#c62828' };
  const statusColor = statusColors[bill.status] || '#555';
  const billNum = '#' + String(bill.id).padStart(4,'0');
  const fmtAmt = v => v != null ? Number(v).toLocaleString('en-IN', {minimumFractionDigits:2}) : '0.00';

  const autoPrintScript = autoPrint
    ? `<script>window.onload=function(){window.print();}<\/script>`
    : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Invoice ${billNum}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'DM Sans',Arial,sans-serif;background:#f5f5f0;color:#1a1a1a;font-size:13px}
  @media print{body{background:#fff}.no-print{display:none!important}.invoice{box-shadow:none!important;margin:0!important}}
  .print-bar{background:#2e7d32;color:#ffffff;padding:12px 32px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
  .print-bar-title{font-size:14px;font-weight:600;letter-spacing:1px;color:#2e7d32}
  .print-btn{background:#2e7d32;color:#ffffff;border:none;border-radius:6px;padding:8px 20px;font-size:13px;font-weight:700;cursor:pointer}
  .print-btn:hover{background:#1b5e20}
  .invoice-wrap{max-width:780px;margin:32px auto;padding:0 16px}
  .invoice{background:#fff;border-radius:8px;box-shadow:0 4px 24px rgba(0,0,0,.10);padding:40px 48px;margin-bottom:32px}
  .inv-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px;border-bottom:2px solid #2e7d32;padding-bottom:20px}
  .inv-logo-title{font-size:28px;font-weight:800;color:#5a8c1a;letter-spacing:1px}
  .inv-logo-sub{font-size:10px;color:#888;letter-spacing:3px;text-transform:uppercase;margin-top:2px}
  .inv-meta{text-align:right}
  .inv-number{font-size:22px;font-weight:800;color:#1a1a1a;margin-bottom:4px}
  .inv-date,.inv-due{font-size:12px;color:#555}
  .inv-status{font-size:15px;margin-top:6px}
  .inv-parties{display:flex;gap:48px;margin-bottom:28px}
  .inv-party{flex:1}
  .party-label{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#2e7d32;font-weight:700;margin-bottom:8px}
  .party-name{font-size:16px;font-weight:700;margin-bottom:4px}
  .party-detail{font-size:12px;color:#555;margin-bottom:2px}
  .inv-table{width:100%;border-collapse:collapse;margin-bottom:20px}
  .inv-table th{background:#f0f4e8;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:#5a8c1a;padding:10px 14px;text-align:left;border-bottom:2px solid #d4e8a0}
  .inv-table td{padding:12px 14px;border-bottom:1px solid #eee;font-size:13px}
  .amount-cell{font-weight:700;font-size:15px;color:#1a1a1a}
  .inv-totals{display:flex;flex-direction:column;align-items:flex-end;gap:4px;margin-bottom:20px}
  .total-row{display:flex;gap:48px;font-size:13px;color:#555}
  .total-row span:last-child{min-width:120px;text-align:right}
  .total-final{font-size:18px;font-weight:800;color:#1a1a1a;border-top:2px solid #1a1a1a;padding-top:8px;margin-top:4px}
  .total-paid{font-size:17px;font-weight:800;color:#2e7d32;border-top:2px solid #2e7d32;padding-top:8px;margin-top:4px}
  .total-pending{font-size:17px;font-weight:800;color:#e65100;border-top:2px solid #e65100;padding-top:8px;margin-top:4px}
  .total-overdue{font-size:17px;font-weight:800;color:#c62828;border-top:2px solid #c62828;padding-top:8px;margin-top:4px}
  .inv-notes{background:#f1f8e9;border-left:3px solid #2e7d32;padding:12px 16px;border-radius:4px;font-size:12px;color:#444;margin-bottom:20px}
  .inv-footer{text-align:center;font-size:11px;color:#aaa;border-top:1px solid #eee;padding-top:16px}
</style>
${autoPrintScript}
</head>
<body>
<div class="print-bar no-print">
  <div class="print-bar-title">🖨️ Invoice ${billNum}</div>
  <div style="display:flex;gap:10px;align-items:center">
    <button class="print-btn" onclick="window.print()">Print / Save as PDF</button>
    <button class="print-btn" style="background:#1565c0" onclick="window.close()">✕ Close</button>
  </div>
</div>
<div class="invoice-wrap">
  <div class="invoice">
    <div class="inv-header">
      <div class="inv-logo">
        <div class="inv-logo-title">Desai Tractor</div>
        <div class="inv-logo-sub">Billing System</div>
      </div>
      <div class="inv-meta">
        <div class="inv-number">INVOICE ${billNum}</div>
        <div class="inv-date">Date: ${fmt(bill.date)}</div>
        <div class="inv-due">Due: ${fmt(bill.due)}</div>
        <div class="inv-status" style="color:${statusColor};font-weight:700">${bill.status}</div>
      </div>
    </div>
    <div class="inv-parties">
      <div class="inv-party">
        <div class="party-label">BILLED TO</div>
        <div class="party-name">${cust.name||'-'}</div>
        <div class="party-detail">📞 ${cust.phone||'-'}</div>
        <div class="party-detail">📍 ${cust.village||'-'}, ${cust.district||'-'}</div>
      </div>
      <div class="inv-party">
        <div class="party-label">TRACTOR DETAILS</div>
        <div class="party-name">${trac.reg||'-'}</div>
        <div class="party-detail">${trac.brand||''} ${trac.model||''}</div>
      </div>
    </div>
    <table class="inv-table">
      <thead>
        <tr><th>Service</th><th>Field Area</th><th>Hours</th><th>Rate/hr (Rs.)</th><th>Amount (Rs.)</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>${bill.service}</td>
          <td>${bill.area ? bill.area + ' ac' : '-'}</td>
          <td>${bill.hours||'-'}</td>
          <td>${bill.rate ? 'Rs.'+bill.rate : '-'}</td>
          <td class="amount-cell">Rs.${fmtAmt(bill.amount)}</td>
        </tr>
      </tbody>
    </table>
    <div class="inv-totals">
      <div class="total-row"><span>Total Invoice Amount</span><span>Rs.${fmtAmt(bill.amount)}</span></div>
      ${bill.status === 'Paid'
        ? `<div class="total-row total-paid"><span>✅ Amount Paid</span><span>Rs.${fmtAmt(bill.paidAmount || bill.amount)}</span></div>
           <div class="total-row"><span style="color:#2e7d32;">Balance Due</span><span style="color:#2e7d32;">Rs.0.00</span></div>`
        : bill.status === 'Pending'
        ? `<div class="total-row"><span>✅ Amount Paid</span><span style="color:#2e7d32;font-weight:700;">Rs.${fmtAmt(bill.paidAmount || 0)}</span></div>
           <div class="total-row total-pending"><span>⏳ Pending Amount</span><span>Rs.${fmtAmt(Math.max(0,(bill.amount||0)-(bill.paidAmount||0)))}</span></div>`
        : `<div class="total-row"><span>✅ Amount Paid</span><span style="color:#2e7d32;font-weight:700;">Rs.${fmtAmt(bill.paidAmount || 0)}</span></div>
           <div class="total-row total-overdue"><span>🔴 Overdue Amount</span><span>Rs.${fmtAmt(Math.max(0,(bill.amount||0)-(bill.paidAmount||0)))}</span></div>`
      }
    </div>
    ${bill.notes ? `<div class="inv-notes"><b>Notes:</b> ${bill.notes}</div>` : ''}
    <div class="inv-footer">Desai Tractor Billing System &nbsp;|&nbsp; Generated on ${new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</div>
  </div>
</div>
</body></html>`;
}

/** Build bulk HTML for multiple bills */
function buildLocalBulkHtml(bills) {
  const fmt = d => d ? new Date(d).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'}) : '-';
  const fmtAmt = v => v != null ? Number(v).toLocaleString('en-IN', {minimumFractionDigits:2}) : '0.00';
  const statusColors = { Paid:'#2e7d32', Pending:'#e65100', Overdue:'#c62828' };

  const invoices = bills.map((bill, i) => {
    const cust = DB.customers.find(c => c.id === bill.customerId) || {};
    const trac = DB.tractors.find(t => t.id === bill.tractorId) || {};
    const statusColor = statusColors[bill.status] || '#555';
    const billNum = '#' + String(bill.id).padStart(4,'0');
    const pb = i < bills.length - 1 ? 'page-break-after:always;' : '';
    return `<div class="invoice" style="${pb}">
      <div class="inv-header">
        <div class="inv-logo"><div class="inv-logo-title">Desai Tractor</div><div class="inv-logo-sub">Billing System</div></div>
        <div class="inv-meta">
          <div class="inv-number">INVOICE ${billNum}</div>
          <div class="inv-date">Date: ${fmt(bill.date)}</div>
          <div class="inv-due">Due: ${fmt(bill.due)}</div>
          <div class="inv-status" style="color:${statusColor};font-weight:700">${bill.status}</div>
        </div>
      </div>
      <div class="inv-parties">
        <div class="inv-party">
          <div class="party-label">BILLED TO</div>
          <div class="party-name">${cust.name||'-'}</div>
          <div class="party-detail">📞 ${cust.phone||'-'}</div>
          <div class="party-detail">📍 ${cust.village||'-'}, ${cust.district||'-'}</div>
        </div>
        <div class="inv-party">
          <div class="party-label">TRACTOR DETAILS</div>
          <div class="party-name">${trac.reg||'-'}</div>
          <div class="party-detail">${trac.brand||''} ${trac.model||''}</div>
        </div>
      </div>
      <table class="inv-table">
        <thead><tr><th>Service</th><th>Field Area</th><th>Hours</th><th>Rate/hr (Rs.)</th><th>Amount (Rs.)</th></tr></thead>
        <tbody>
          <tr>
            <td>${bill.service}</td><td>${bill.area ? bill.area+' ac' : '-'}</td>
            <td>${bill.hours||'-'}</td><td>${bill.rate ? 'Rs.'+bill.rate : '-'}</td>
            <td class="amount-cell">Rs.${fmtAmt(bill.amount)}</td>
          </tr>
        </tbody>
      </table>
      <div class="inv-totals">
        <div class="total-row"><span>Total Invoice Amount</span><span>Rs.${fmtAmt(bill.amount)}</span></div>
        ${bill.status === 'Paid'
          ? `<div class="total-row total-paid"><span>✅ Amount Paid</span><span>Rs.${fmtAmt(bill.paidAmount || bill.amount)}</span></div><div class="total-row"><span style="color:#2e7d32;">Balance Due</span><span style="color:#2e7d32;">Rs.0.00</span></div>`
          : bill.status === 'Pending'
          ? `<div class="total-row"><span>✅ Amount Paid</span><span style="color:#2e7d32;font-weight:700;">Rs.${fmtAmt(bill.paidAmount || 0)}</span></div><div class="total-row total-pending"><span>⏳ Pending Amount</span><span>Rs.${fmtAmt(Math.max(0,(bill.amount||0)-(bill.paidAmount||0)))}</span></div>`
          : `<div class="total-row"><span>✅ Amount Paid</span><span style="color:#2e7d32;font-weight:700;">Rs.${fmtAmt(bill.paidAmount || 0)}</span></div><div class="total-row total-overdue"><span>🔴 Overdue Amount</span><span>Rs.${fmtAmt(Math.max(0,(bill.amount||0)-(bill.paidAmount||0)))}</span></div>`
        }
      </div>
      ${bill.notes ? `<div class="inv-notes"><b>Notes:</b> ${bill.notes}</div>` : ''}
      <div class="inv-footer">Desai Tractor Billing System &nbsp;|&nbsp; Generated ${new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</div>
    </div>`;
  }).join('\n');

  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Bills Report (${bills.length})</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'DM Sans',Arial,sans-serif;background:#f5f5f0;color:#1a1a1a;font-size:13px}
  @media print{body{background:#fff}.no-print{display:none!important}.invoice{box-shadow:none!important;margin:0!important}}
  .print-bar{background:#2e7d32;color:#ffffff;padding:12px 32px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
  .print-bar-title{font-size:14px;font-weight:600;letter-spacing:1px;color:#2e7d32}
  .print-btn{background:#2e7d32;color:#ffffff;border:none;border-radius:6px;padding:8px 20px;font-size:13px;font-weight:700;cursor:pointer}
  .invoice-wrap{max-width:780px;margin:32px auto;padding:0 16px}
  .invoice{background:#fff;border-radius:8px;box-shadow:0 4px 24px rgba(0,0,0,.10);padding:40px 48px;margin-bottom:32px}
  .inv-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px;border-bottom:2px solid #2e7d32;padding-bottom:20px}
  .inv-logo-title{font-size:28px;font-weight:800;color:#5a8c1a;letter-spacing:1px}
  .inv-logo-sub{font-size:10px;color:#888;letter-spacing:3px;text-transform:uppercase;margin-top:2px}
  .inv-meta{text-align:right}
  .inv-number{font-size:22px;font-weight:800;color:#1a1a1a;margin-bottom:4px}
  .inv-date,.inv-due{font-size:12px;color:#555}
  .inv-status{font-size:15px;margin-top:6px}
  .inv-parties{display:flex;gap:48px;margin-bottom:28px}
  .inv-party{flex:1}
  .party-label{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#2e7d32;font-weight:700;margin-bottom:8px}
  .party-name{font-size:16px;font-weight:700;margin-bottom:4px}
  .party-detail{font-size:12px;color:#555;margin-bottom:2px}
  .inv-table{width:100%;border-collapse:collapse;margin-bottom:20px}
  .inv-table th{background:#f0f4e8;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:#5a8c1a;padding:10px 14px;text-align:left;border-bottom:2px solid #d4e8a0}
  .inv-table td{padding:12px 14px;border-bottom:1px solid #eee;font-size:13px}
  .amount-cell{font-weight:700;font-size:15px}
  .inv-totals{display:flex;flex-direction:column;align-items:flex-end;gap:4px;margin-bottom:20px}
  .total-row{display:flex;gap:48px;font-size:13px;color:#555}
  .total-row span:last-child{min-width:120px;text-align:right}
  .total-final{font-size:18px;font-weight:800;color:#1a1a1a;border-top:2px solid #1a1a1a;padding-top:8px;margin-top:4px}
  .total-paid{font-size:17px;font-weight:800;color:#2e7d32;border-top:2px solid #2e7d32;padding-top:8px;margin-top:4px}
  .total-pending{font-size:17px;font-weight:800;color:#e65100;border-top:2px solid #e65100;padding-top:8px;margin-top:4px}
  .total-overdue{font-size:17px;font-weight:800;color:#c62828;border-top:2px solid #c62828;padding-top:8px;margin-top:4px}
  .inv-notes{background:#f1f8e9;border-left:3px solid #2e7d32;padding:12px 16px;border-radius:4px;font-size:12px;color:#444;margin-bottom:20px}
  .inv-footer{text-align:center;font-size:11px;color:#aaa;border-top:1px solid #eee;padding-top:16px}
</style>
</head><body>
<div class="print-bar no-print">
  <div class="print-bar-title">🖨️ Bills Report - ${bills.length} invoice${bills.length!==1?'s':''}</div>
  <div style="display:flex;gap:10px;align-items:center">
    <button class="print-btn" onclick="window.print()">Print / Save as PDF</button>
    <button class="print-btn" style="background:#1565c0" onclick="window.close()">✕ Close</button>
  </div>
</div>
<div class="invoice-wrap">${invoices}</div>
</body></html>`;
}

/** Open invoice preview in the modal */
function previewInvoice(billId) {
  currentPdfBillId = billId;
  const billNum = '#' + String(billId).padStart(4,'0');
  document.getElementById('pdfPreviewTitle').textContent = 'INVOICE ' + billNum;

  const html = buildLocalInvoiceHtml(billId, false);
  const blob = new Blob([html], { type: 'text/html' });
  const url  = URL.createObjectURL(blob);
  document.getElementById('pdfPreviewFrame').src = url;
  openModal('pdfPreviewModal');
}

/** Print current previewed invoice */
function printCurrentInvoice() {
  if (currentPdfBillId == null) return;
  printBillInvoice(currentPdfBillId);
}

/** Open individual bill invoice in new tab -> browser print dialog */
function printBillInvoice(billId) {
  // Always generate locally as a blob URL so the new tab never hits an auth guard
  const html = buildLocalInvoiceHtml(billId, true);
  const blob = new Blob([html], { type: 'text/html' });
  const url  = URL.createObjectURL(blob);
  const win  = window.open(url, '_blank');
  if (!win) showToast('Please allow popups for PDF printing.', 'error');
}

/** Print all bills */
function bulkPrintAll() {
  const bills = DB.bills;
  if (!bills.length) { showToast('No bills to print.', 'error'); return; }
  openBulkPrint(bills, 'All Bills');
}

/** Print only the currently filtered bills */
function bulkPrintFiltered() {
  const q  = document.getElementById('pdfSearch').value.toLowerCase();
  const st = document.getElementById('pdfStatusFilter').value;
  const mo = document.getElementById('pdfMonthFilter').value;
  const filtered = allPdfBills.filter(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId);
    const trac = DB.tractors.find(t=>t.id===b.tractorId);
    const text = `${b.id} ${cust?.name||''} ${trac?.reg||''} ${b.service}`.toLowerCase();
    return text.includes(q) && (!st || b.status===st) && (!mo || b.date.startsWith(mo));
  });
  if (!filtered.length) { showToast('No bills match current filter.', 'error'); return; }
  openBulkPrint(filtered, `${filtered.length} Bills`);
}

/** Open Daily Report – reads date from dailyIncomeDate (Reports page) or dailyReportDate fallback */
function openDailyReport() {
  const dateInput = document.getElementById('dailyIncomeDate') || document.getElementById('dailyReportDate');
  const selectedDate = dateInput ? dateInput.value : new Date().toISOString().split('T')[0];
  // Always generate locally as a blob URL so the new tab never hits an auth guard
  const date = selectedDate;
  const bills = DB.bills.filter(b => b.date && b.date.startsWith(date));
  const html = buildLocalDailyReport(date, bills);
  const blob = new Blob([html], { type: 'text/html' });
  const url  = URL.createObjectURL(blob);
  const win  = window.open(url, '_blank');
  if (!win) showToast('Please allow popups.', 'error');
  else showToast('Opening daily report...', 'success');
}

/** Load and display Daily Income Report in the Reports section */
let allDailyIncomeBills = [];
function loadDailyIncome() {
  const dateInput = document.getElementById('dailyIncomeDate');
  const date = dateInput ? dateInput.value : new Date().toISOString().split('T')[0];
  if (!date) { showToast('Please select a date.', 'error'); return; }
  allDailyIncomeBills = DB.bills.filter(b => b.date && b.date.startsWith(date));
  renderDailyIncomeTable(allDailyIncomeBills);
}

function filterDailyIncome() {
  const q = (document.getElementById('dailyIncomeSearch')?.value || '').toLowerCase();
  const filtered = allDailyIncomeBills.filter(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId);
    return `${cust?.name||''} ${b.service} ${b.notes||''}`.toLowerCase().includes(q);
  });
  renderDailyIncomeTable(filtered);
}

function renderDailyIncomeTable(bills) {
  const fmtAmt = v => v != null ? Number(v).toLocaleString('en-IN', {minimumFractionDigits:2}) : '0.00';
  const fmt = d => d ? new Date(d).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'}) : '-';
  const tbody = document.getElementById('dailyIncomeBody');
  const cardsDiv = document.getElementById('dailyIncomeCards');

  const paidAmt    = bills.filter(b=>b.status==='Paid').reduce((s,b)=>s+(b.paidAmount||b.amount||0),0);
  const pendingAmt = bills.filter(b=>b.status==='Pending').reduce((s,b)=>s+Math.max(0,(b.amount||0)-(b.paidAmount||0)),0);
  const overdueAmt = bills.filter(b=>b.status==='Overdue').reduce((s,b)=>s+Math.max(0,(b.amount||0)-(b.paidAmount||0)),0);

  // Update summary cards
  cardsDiv.style.display = 'flex';
  document.getElementById('dailyIncomePaid').textContent = 'Rs.' + fmtAmt(paidAmt);
  document.getElementById('dailyIncomePending').textContent = 'Rs.' + fmtAmt(pendingAmt);
  document.getElementById('dailyIncomeOverdue').textContent = 'Rs.' + fmtAmt(overdueAmt);
  document.getElementById('dailyIncomeBills').textContent = bills.length;

  if (!bills.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="loading">No bills found for this date / search.</td></tr>';
    return;
  }
  const badges = { Paid:'badge-paid', Pending:'badge-pending', Overdue:'badge-overdue' };
  tbody.innerHTML = bills.map(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId)||{};
    return `<tr>
      <td>#${String(b.id).padStart(4,'0')}</td>
      <td>${cust.name||'Unknown'}</td>
      <td>${cust.phone||'—'}</td>
      <td>${b.service}</td>
      <td>Rs.${fmtAmt(b.amount)}</td>
      <td>${fmt(b.due)}</td>
      <td><span class="badge ${badges[b.status]||''}">${b.status}</span></td>
      <td>${b.notes||'—'}</td>
    </tr>`;
  }).join('');
}

/** Build local daily report HTML */
function buildLocalDailyReport(date, bills) {
  const fmt = d => d ? new Date(d).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'}) : '-';
  const fmtAmt = v => v != null ? Number(v).toLocaleString('en-IN', {minimumFractionDigits:2}) : '0.00';
  const dateLabel = fmt(date);
  const paidAmt    = bills.filter(b=>b.status==='Paid').reduce((s,b)=>s+(b.paidAmount||b.amount||0),0);
  const pendingAmt = bills.filter(b=>b.status==='Pending').reduce((s,b)=>s+Math.max(0,(b.amount||0)-(b.paidAmount||0)),0);
  const overdueAmt = bills.filter(b=>b.status==='Overdue').reduce((s,b)=>s+Math.max(0,(b.amount||0)-(b.paidAmount||0)),0);
  const rows = bills.map(b => {
    const cust = DB.customers.find(c=>c.id===b.customerId)||{};
    const statusColors = { Paid:'#2e7d32', Pending:'#e65100', Overdue:'#c62828' };
    const col = statusColors[b.status]||'#555';
    return `<tr>
      <td>#${String(b.id).padStart(4,'0')}</td>
      <td>${cust.name||'-'}</td><td>${cust.phone||'-'}</td><td>${b.service}</td>
      <td>Rs.${fmtAmt(b.amount)}</td>
      <td>${fmt(b.due)}</td>
      <td style="color:#2e7d32;font-weight:600">${(b.paidAmount>0?'Rs.'+fmtAmt(b.paidAmount):'—')}</td>
      <td style="color:#e65100;font-weight:600">${b.status==='Pending'?'Rs.'+fmtAmt(Math.max(0,(b.amount||0)-(b.paidAmount||0))):'—'}</td>
      <td style="color:#c62828;font-weight:600">${b.status==='Overdue'?'Rs.'+fmtAmt(Math.max(0,(b.amount||0)-(b.paidAmount||0))):'—'}</td>
      <td><span style="color:${col};font-weight:700;background:${col}20;padding:2px 10px;border-radius:20px;font-size:11px">${b.status}</span></td>
      <td>${b.notes||'—'}</td>
    </tr>`;
  }).join('');
  const tableOrEmpty = bills.length
    ? `<div style="overflow-x:auto;margin-bottom:32px"><table style="width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.06)">
        <thead><tr style="background:#5a8c1a;color:#fff;font-size:11px;text-transform:uppercase;letter-spacing:.8px">
          <th style="padding:12px 14px">Bill #</th><th style="padding:12px 14px">Customer</th><th style="padding:12px 14px">Phone</th>
          <th style="padding:12px 14px">Service</th><th style="padding:12px 14px">Total</th><th style="padding:12px 14px">Due Date</th>
          <th style="padding:12px 14px">Paid</th><th style="padding:12px 14px">Pending</th><th style="padding:12px 14px">Overdue</th>
          <th style="padding:12px 14px">Status</th><th style="padding:12px 14px">Notes</th>
        </tr></thead><tbody>${rows}</tbody>
      </table></div>`
    : `<div style="text-align:center;padding:40px;color:#888;font-size:16px;">No bills found for this date.</div>`;
  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Daily Report – ${dateLabel}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'DM Sans',Arial,sans-serif;background:#f5f5f0;color:#1a1a1a;font-size:13px}
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;800&display=swap');
  @media print{body{background:#fff}.no-print{display:none!important}}
  .print-bar{background:#0d0f0a;color:#e8ead8;padding:12px 32px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
  .print-bar-title{font-size:14px;font-weight:600;letter-spacing:1px;color:#8fba2e}
  .print-btn{background:#8fba2e;color:#0d0f0a;border:none;border-radius:6px;padding:8px 20px;font-size:13px;font-weight:700;cursor:pointer}
  .wrap{max-width:1000px;margin:32px auto;padding:0 16px}
  .banner{background:#fff;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,.08);padding:24px 32px;margin-bottom:28px}
  .banner-title{font-size:16px;font-weight:700;color:#333;margin-bottom:18px}
  .cards{display:flex;gap:16px;flex-wrap:wrap}
  .card{flex:1;min-width:160px;border-radius:8px;padding:16px 20px;text-align:center}
  .card-label{font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px}
  .card-amt{font-size:22px;font-weight:800}
  .card-paid{background:#e8f5e9;color:#2e7d32}
  .card-pending{background:#fff3e0;color:#e65100}
  .card-overdue{background:#ffebee;color:#c62828}
  table td{padding:10px 14px;border-bottom:1px solid #f0f0f0;vertical-align:middle}
  table tr:hover td{background:#f9fbf5}
</style>
</head><body>
<div class="print-bar no-print">
  <div class="print-bar-title">🚜 Daily Report – ${dateLabel}</div>
  <div style="display:flex;gap:10px;align-items:center">
    <button class="print-btn" onclick="window.print()">🖨️ Print / Save PDF</button>
    <button class="print-btn" style="background:#1565c0" onclick="window.close()">✕ Close</button>
  </div>
</div>
<div class="wrap">
  <div class="banner">
    <div class="banner-title">📊 Daily Report – ${dateLabel} &nbsp;|&nbsp; ${bills.length} Bill(s)</div>
    <div class="cards">
      <div class="card card-paid"><div class="card-label">✅ Total Paid</div><div class="card-amt">Rs.${fmtAmt(paidAmt)}</div></div>
      <div class="card card-pending"><div class="card-label">⏳ Total Pending</div><div class="card-amt">Rs.${fmtAmt(pendingAmt)}</div></div>
      <div class="card card-overdue"><div class="card-label">🔴 Total Overdue</div><div class="card-amt">Rs.${fmtAmt(overdueAmt)}</div></div>
    </div>
  </div>
  ${tableOrEmpty}
</div>
</body></html>`;
}

function openBulkPrint(bills, label) {
  const html = buildLocalBulkHtml(bills);
  const blob = new Blob([html], { type: 'text/html' });
  const url  = URL.createObjectURL(blob);
  const win  = window.open(url, '_blank');
  if (!win) showToast('Please allow popups for PDF printing.', 'error');
  else showToast(`Opening ${label} for printing...`, 'success');
}


function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function clearForm(ids) { ids.forEach(id => { const el = document.getElementById(id); if(el) el.value=''; }); }
function setFormVal(id, val) { const el = document.getElementById(id); if(el) el.value=val||''; }

function showToast(msg, type='success') {
  const c = document.getElementById('toastContainer');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span>${type==='success'?'✅':'❌'}</span> ${msg}`;
  c.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}


// ===============================================
//  ACRE RATE PAGE
// ===============================================
let allAcreRates = [];
let editingAcreRateId = null;

const SERVICE_ICONS = {
  'Ploughing':'🌾','Harrowing':'🔧','Sowing':'🌱','Harvesting':'🌻',
  'Transport':'🚛','Rotavation':'⚙️','Other':'🔩'
};

async function loadAcreRates() {
  allAcreRates = await apiGet('/acrerates');
  renderAcreRateStats(allAcreRates);
  filterAcreRates();
}

function renderAcreRateStats(rates) {
  const active = rates.filter(r=>r.status==='Active');
  document.getElementById('ar-stat-total').textContent = rates.length;
  const avg = active.length ? Math.round(active.reduce((s,r)=>s+r.rate,0)/active.length) : 0;
  document.getElementById('ar-stat-avg').textContent = 'Rs.'+avg.toLocaleString('en-IN');
  if (active.length) {
    const minR = active.reduce((a,b)=>a.rate<b.rate?a:b);
    const maxR = active.reduce((a,b)=>a.rate>b.rate?a:b);
    document.getElementById('ar-stat-min').textContent = 'Rs.'+minR.rate.toLocaleString('en-IN');
    document.getElementById('ar-stat-min-svc').textContent = minR.service;
    document.getElementById('ar-stat-max').textContent = 'Rs.'+maxR.rate.toLocaleString('en-IN');
    document.getElementById('ar-stat-max-svc').textContent = maxR.service;
  }
}

function filterAcreRates() {
  const q = document.getElementById('acreRateSearch').value.toLowerCase();
  const season = document.getElementById('acreRateSeasonFilter').value;
  const filtered = allAcreRates.filter(r => {
    const text = `${r.service} ${r.tractorType} ${r.notes}`.toLowerCase();
    return text.includes(q) && (!season || r.season === season || r.season === 'All Season' && !season);
  });
  renderAcreRateGrid(filtered);
  renderAcreRateTable(filtered);
}

function renderAcreRateGrid(rates) {
  const grid = document.getElementById('acreRateGrid');
  if (!rates.length) { grid.innerHTML = '<div class="empty-state"><div class="icon">🌾</div><p>No acre rates found.</p></div>'; return; }
  const cardTypes = ['', 'warn', 'info'];
  grid.innerHTML = rates.map((r, i) => `
    <div class="rate-card ${cardTypes[i%3]}">
      <div class="rate-card-header">
        <div>
          <div class="rate-service-name">${r.service}</div>
          <div style="font-size:11px;color:var(--text2);margin-top:2px">${r.tractorType} . ${r.season}</div>
        </div>
        <div class="rate-icon">${SERVICE_ICONS[r.service]||'🌾'}</div>
      </div>
      <div class="rate-value">Rs.${r.rate.toLocaleString('en-IN')}</div>
      <div class="rate-unit">Per Acre</div>
      <div class="rate-meta">
        <span>Min: ${r.minAcres} acre${r.minAcres!==1?'s':''}</span>
        <span>${r.discount>0?'Discount: '+r.discount+'%':'No discount'}</span>
        <span class="badge ${r.status==='Active'?'badge-paid':'badge-overdue'}">${r.status}</span>
      </div>
      ${r.notes ? `<div style="font-size:11px;color:var(--text2);margin-top:8px;font-style:italic">${r.notes}</div>` : ''}
      <div class="rate-card-actions">
        <button class="btn btn-ghost btn-sm" onclick="editAcreRate(${r.id})">✏️ Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteAcreRate(${r.id})">🗑️</button>
      </div>
    </div>
  `).join('');
}

function renderAcreRateTable(rates) {
  const tbody = document.getElementById('acreRateTableBody');
  if (!rates.length) { tbody.innerHTML = '<tr><td colspan="9" class="loading">No rates found.</td></tr>'; return; }
  tbody.innerHTML = rates.map(r => `<tr>
    <td>#${r.id}</td>
    <td style="font-family:'DM Sans';font-weight:600">${SERVICE_ICONS[r.service]||''} ${r.service}</td>
    <td>${r.tractorType}</td>
    <td style="font-weight:700;color:var(--accent)">Rs.${r.rate.toLocaleString('en-IN')}</td>
    <td>${r.minAcres} ac</td>
    <td>${r.season}</td>
    <td>${r.effectiveDate}</td>
    <td><span class="badge ${r.status==='Active'?'badge-paid':'badge-overdue'}">${r.status}</span></td>
    <td>
      <div class="action-btns">
        <button class="btn btn-ghost btn-sm" onclick="editAcreRate(${r.id})">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteAcreRate(${r.id})">🗑️</button>
      </div>
    </td>
  </tr>`).join('');
}

function openAcreRateModal() {
  editingAcreRateId = null;
  document.getElementById('acreRateModalTitle').textContent = 'ADD ACRE RATE';
  clearForm(['ar-service','ar-tractortype','ar-rate','ar-minacres','ar-season','ar-effectivedate','ar-status','ar-discount','ar-notes']);
  document.getElementById('ar-minacres').value = '1';
  document.getElementById('ar-discount').value = '0';
  document.getElementById('ar-effectivedate').value = new Date().toISOString().split('T')[0];
  openModal('acreRateModal');
}

async function editAcreRate(id) {
  editingAcreRateId = id;
  const r = await apiGet('/acrerates/' + id);
  document.getElementById('acreRateModalTitle').textContent = 'EDIT ACRE RATE';
  setFormVal('ar-service', r.service);
  setFormVal('ar-tractortype', r.tractorType);
  setFormVal('ar-rate', r.rate);
  setFormVal('ar-minacres', r.minAcres);
  setFormVal('ar-season', r.season);
  setFormVal('ar-effectivedate', r.effectiveDate);
  setFormVal('ar-status', r.status);
  setFormVal('ar-discount', r.discount);
  setFormVal('ar-notes', r.notes);
  openModal('acreRateModal');
}

async function saveAcreRate() {
  const data = {
    service: document.getElementById('ar-service').value,
    tractorType: document.getElementById('ar-tractortype').value,
    rate: parseFloat(document.getElementById('ar-rate').value) || 0,
    minAcres: parseFloat(document.getElementById('ar-minacres').value) || 1,
    season: document.getElementById('ar-season').value,
    effectiveDate: document.getElementById('ar-effectivedate').value,
    status: document.getElementById('ar-status').value,
    discount: parseFloat(document.getElementById('ar-discount').value) || 0,
    notes: document.getElementById('ar-notes').value,
  };
  if (!data.rate) { showToast('Rate per acre is required.','error'); return; }
  if (editingAcreRateId) {
    await apiPut('/acrerates/' + editingAcreRateId, data);
    showToast('Acre rate updated!','success');
  } else {
    await apiPost('/acrerates', data);
    showToast('Acre rate added!','success');
  }
  closeModal('acreRateModal');
  loadAcreRates();
}

async function deleteAcreRate(id) {
  if (!confirm('Delete this acre rate?')) return;
  await apiDelete('/acrerates/' + id);
  showToast('Acre rate deleted.','success');
  loadAcreRates();
}

function exportAcreRateCSV() {
  const header = ['#','Service','Tractor Type','Rate/Acre (Rs.)','Min Acres','Season','Effective From','Status','Discount (%)','Notes'];
  const rows = allAcreRates.map(r => [r.id, r.service, r.tractorType, r.rate, r.minAcres, r.season, r.effectiveDate, r.status, r.discount, r.notes]);
  const csv = [header,...rows].map(r=>r.join(',')).join('\n');
  const a = document.createElement('a');
  a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  a.download = 'acre-rates.csv';
  a.click();
  showToast('Acre rates CSV exported!','success');
}

// ===============================================
//  SERVICES PAGE
// ===============================================
let allServices = [];
let editingServiceId = null;

async function loadServices() {
  allServices = await apiGet('/services');
  renderServiceStats(allServices);
  filterServices();
}

function renderServiceStats(svcs) {
  const active = svcs.filter(s=>s.status==='Active');
  document.getElementById('svc-stat-total').textContent = svcs.length;
  document.getElementById('svc-stat-active').textContent = active.length;
  // Most used service by bill count
  const usageCounts = {};
  DB.bills.forEach(b => { usageCounts[b.service] = (usageCounts[b.service]||0) + 1; });
  const topSvc = Object.entries(usageCounts).sort((a,b)=>b[1]-a[1])[0];
  document.getElementById('svc-stat-popular').textContent = topSvc ? topSvc[0] : '-';
  const avgRate = active.length ? Math.round(active.reduce((s,sv)=>s+sv.rateHr,0)/active.length) : 0;
  document.getElementById('svc-stat-avgrate').textContent = 'Rs.'+avgRate;
}

function filterServices() {
  const q = document.getElementById('serviceSearch').value.toLowerCase();
  const st = document.getElementById('serviceStatusFilter').value;
  const filtered = allServices.filter(s => {
    const text = `${s.name} ${s.category} ${s.desc} ${s.equipment}`.toLowerCase();
    return text.includes(q) && (!st || s.status === st);
  });
  renderServiceGrid(filtered);
  renderServiceTable(filtered);
}

function renderServiceGrid(svcs) {
  const grid = document.getElementById('serviceListGrid');
  if (!svcs.length) { grid.innerHTML = '<div class="empty-state"><div class="icon">⚙️</div><p>No services found.</p></div>'; return; }
  grid.innerHTML = svcs.map(s => {
    const billCount = DB.bills.filter(b=>b.service===s.name).length;
    return `<div class="service-list-card">
      <div class="service-emoji">${s.icon||'⚙️'}</div>
      <div class="service-info">
        <div class="service-name-big">${s.name}</div>
        <div class="service-desc">${s.desc}</div>
        <div style="font-size:11px;color:var(--text2);margin-top:4px">📦 ${s.equipment} . ⏱️ ~${s.duration}h/acre</div>
        <span class="service-rate-pill">Rs.${s.rateHr}/hr . Rs.${s.rateAcre}/acre</span>
        <span class="badge ${s.status==='Active'?'badge-paid':'badge-overdue'}" style="margin-left:6px">${s.status}</span>
      </div>
      <div class="service-card-actions">
        <div style="font-size:11px;color:var(--text2);text-align:right">${s.category}<br><span style="color:var(--accent);font-weight:600">${billCount} bills</span></div>
        <button class="btn btn-ghost btn-sm" onclick="editService(${s.id})">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteService(${s.id})">🗑️</button>
      </div>
    </div>`;
  }).join('');
}

function renderServiceTable(svcs) {
  const tbody = document.getElementById('serviceTableBody');
  if (!svcs.length) { tbody.innerHTML = '<tr><td colspan="9" class="loading">No services found.</td></tr>'; return; }
  tbody.innerHTML = svcs.map(s => {
    const billCount = DB.bills.filter(b=>b.service===s.name).length;
    return `<tr>
      <td>#${s.id}</td>
      <td style="font-family:'DM Sans';font-weight:600">${s.icon||''} ${s.name}</td>
      <td>${s.category}</td>
      <td>Rs.${s.rateHr.toLocaleString('en-IN')}</td>
      <td>Rs.${s.rateAcre.toLocaleString('en-IN')}</td>
      <td>~${s.duration}h/acre</td>
      <td><span class="badge ${s.status==='Active'?'badge-paid':'badge-overdue'}">${s.status}</span></td>
      <td><span class="stat-badge">${billCount}</span></td>
      <td>
        <div class="action-btns">
          <button class="btn btn-ghost btn-sm" onclick="editService(${s.id})">✏️</button>
          <button class="btn btn-danger btn-sm" onclick="deleteService(${s.id})">🗑️</button>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function openServiceModal() {
  editingServiceId = null;
  document.getElementById('serviceModalTitle').textContent = 'ADD SERVICE';
  clearForm(['svc-name','svc-category','svc-ratehr','svc-rateacre','svc-duration','svc-status','svc-icon','svc-equipment','svc-desc']);
  openModal('serviceModal');
}

async function editService(id) {
  editingServiceId = id;
  const s = await apiGet('/services/' + id);
  document.getElementById('serviceModalTitle').textContent = 'EDIT SERVICE';
  setFormVal('svc-name', s.name);
  setFormVal('svc-category', s.category);
  setFormVal('svc-ratehr', s.rateHr);
  setFormVal('svc-rateacre', s.rateAcre);
  setFormVal('svc-duration', s.duration);
  setFormVal('svc-status', s.status);
  setFormVal('svc-icon', s.icon);
  setFormVal('svc-equipment', s.equipment);
  setFormVal('svc-desc', s.desc);
  openModal('serviceModal');
}

async function saveService() {
  const data = {
    name: document.getElementById('svc-name').value.trim(),
    category: document.getElementById('svc-category').value,
    rateHr: parseFloat(document.getElementById('svc-ratehr').value) || 0,
    rateAcre: parseFloat(document.getElementById('svc-rateacre').value) || 0,
    duration: parseFloat(document.getElementById('svc-duration').value) || 0,
    status: document.getElementById('svc-status').value,
    icon: document.getElementById('svc-icon').value || '⚙️',
    equipment: document.getElementById('svc-equipment').value,
    desc: document.getElementById('svc-desc').value,
  };
  if (!data.name) { showToast('Service name is required.','error'); return; }
  if (editingServiceId) {
    await apiPut('/services/' + editingServiceId, data);
    showToast('Service updated!','success');
  } else {
    await apiPost('/services', data);
    showToast('Service added!','success');
  }
  closeModal('serviceModal');
  loadServices();
}

async function deleteService(id) {
  if (!confirm('Delete this service?')) return;
  await apiDelete('/services/' + id);
  showToast('Service deleted.','success');
  loadServices();
}

function exportServicesCSV() {
  const header = ['#','Name','Category','Rate/Hr (Rs.)','Rate/Acre (Rs.)','Duration (hr/acre)','Status','Equipment','Description'];
  const rows = allServices.map(s => [s.id, s.name, s.category, s.rateHr, s.rateAcre, s.duration, s.status, s.equipment, s.desc]);
  const csv = [header,...rows].map(r=>r.join(',')).join('\n');
  const a = document.createElement('a');
  a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  a.download = 'services.csv';
  a.click();
  showToast('Services CSV exported!','success');
}

// ===============================================
//  INIT
// ===============================================
async function checkBackend() {
  try {
    const r = await fetch(API_BASE + '/health', { signal: AbortSignal.timeout(2000) });
    if (r.ok) {
      useLocalData = false;
      document.getElementById('apiStatus').textContent = 'Backend Connected';
    } else throw new Error();
  } catch {
    useLocalData = true;
    document.getElementById('apiStatus').textContent = 'Demo Mode (Local)';
  }
}

window.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    document.querySelectorAll('.modal-overlay').forEach(m=>m.classList.remove('open'));
  }
});

(async () => {
  await checkBackend();
  loadDashboard();
})();