-- ════════════════════════════════════════════════
--  Desai Tractor Billing System
--  MySQL Database Schema + Seed Data
--  Run this script in MySQL Workbench or CLI:
--    mysql -u root -p < schema.sql
-- ════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS tractor_billing
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE tractor_billing;

-- ── CUSTOMERS ───────────────────────────────────
CREATE TABLE IF NOT EXISTS customers (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    phone      VARCHAR(15),
    village    VARCHAR(100),
    district   VARCHAR(100),
    aadhar     VARCHAR(20),
    land       DECIMAL(8,2) COMMENT 'Land area in acres',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_village (village)
) ENGINE=InnoDB;

-- ── TRACTORS ────────────────────────────────────
CREATE TABLE IF NOT EXISTS tractors (
    id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    reg     VARCHAR(20) NOT NULL UNIQUE COMMENT 'Registration Number',
    brand   VARCHAR(50),
    model   VARCHAR(50),
    hp      INT         COMMENT 'Horsepower',
    year    INT,
    status  ENUM('Active','Maintenance','Idle') NOT NULL DEFAULT 'Active',
    owner   VARCHAR(100),
    rate    DECIMAL(10,2) COMMENT 'Rate per hour in INR',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ── BILLS ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS bills (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    tractor_id  BIGINT NOT NULL,
    service     VARCHAR(50) NOT NULL,
    hours       DECIMAL(8,2),
    rate        DECIMAL(10,2),
    amount      DECIMAL(12,2) NOT NULL,
    date        DATE NOT NULL,
    due         DATE,
    status      ENUM('Paid','Pending','Overdue') NOT NULL DEFAULT 'Pending',
    paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Amount already paid by customer',
    area        DECIMAL(8,2) COMMENT 'Field area in acres',
    notes       VARCHAR(500),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
    FOREIGN KEY (tractor_id)  REFERENCES tractors(id)  ON DELETE RESTRICT,
    INDEX idx_status  (status),
    INDEX idx_date    (date),
    INDEX idx_customer(customer_id),
    INDEX idx_tractor (tractor_id)
) ENGINE=InnoDB;

-- ════════════════════════════════════════════════
--  SEED DATA
-- ════════════════════════════════════════════════

INSERT INTO customers (name, phone, village, district, land) VALUES
('Ramesh Patel',    '9876543210', 'Borsad',    'Anand',  12.0),
('Suresh Desai',    '9765432109', 'Khambhat',  'Anand',   8.0),
('Mahesh Shah',     '9654321098', 'Tarapur',   'Anand',  15.0),
('Naresh Joshi',    '9543210987', 'Petlad',    'Anand',   6.0),
('Dinesh Solanki',  '9432109876', 'Umreth',    'Anand',  10.0),
('Kamlesh Parmar',  '9321098765', 'Balasinor', 'Kheda',   9.0);

INSERT INTO tractors (reg, brand, model, hp, year, status, owner, rate) VALUES
('GJ-05-AB-1234', 'Mahindra',   '575 DI', 42, 2020, 'Active',      'Raju Patel',    350.00),
('GJ-05-CD-5678', 'John Deere', '5310',   55, 2022, 'Active',      'Suresh Sharma', 400.00),
('GJ-05-EF-9012', 'Sonalika',   'DI 60',  60, 2021, 'Maintenance', 'Mukesh Verma',  450.00);

INSERT INTO bills (customer_id, tractor_id, service, hours, rate, amount, paid_amount, date, due, status, area, notes) VALUES
(1, 1, 'Ploughing',   8,  350, 2800, 2800, '2025-01-05', '2025-01-20', 'Paid',    4.0, 'North field'),
(2, 2, 'Harvesting',  12, 400, 4800, 4800, '2025-01-12', '2025-01-27', 'Paid',    6.0, NULL),
(3, 1, 'Sowing',       5, 300, 1500,    0, '2025-02-03', '2025-02-18', 'Pending', 3.0, 'Wheat crop'),
(1, 3, 'Transport',    3, 450, 1350, 1350, '2025-02-15', '2025-03-01', 'Paid',    0.0, NULL),
(4, 2, 'Harrowing',    6, 350, 2100,    0, '2025-03-08', '2025-03-23', 'Overdue', 5.0, NULL),
(2, 1, 'Rotavation',   7, 380, 2660, 2660, '2025-03-18', '2025-04-02', 'Paid',    3.5, NULL),
(5, 3, 'Ploughing',   10, 350, 3500, 1500, '2025-04-02', '2025-04-17', 'Pending', 7.0, 'Deep plough'),
(3, 2, 'Harvesting',  14, 400, 5600, 5600, '2025-04-20', '2025-05-05', 'Paid',    8.0, NULL),
(6, 1, 'Sowing',       4, 300, 1200,    0, '2025-05-10', '2025-05-25', 'Pending', 2.0, NULL),
(4, 3, 'Ploughing',    9, 350, 3150,  500, '2025-05-22', '2025-06-06', 'Overdue', 5.5, 'Red soil'),
(1, 2, 'Transport',    5, 450, 2250, 2250, '2025-06-05', '2025-06-20', 'Paid',    0.0, NULL),
(5, 1, 'Harrowing',    8, 350, 2800, 2800, '2025-06-18', '2025-07-03', 'Paid',    4.0, NULL),
(2, 3, 'Rotavation',   6, 380, 2280, 2280, '2025-07-08', '2025-07-23', 'Paid',    3.0, NULL),
(6, 2, 'Ploughing',   11, 350, 3850,    0, '2025-08-01', '2025-08-16', 'Pending', 6.0, NULL),
(3, 1, 'Harvesting',  15, 400, 6000, 6000, '2025-08-25', '2025-09-09', 'Paid',    9.0, 'Good yield');

-- ── Useful Views ─────────────────────────────────
CREATE OR REPLACE VIEW v_billing_summary AS
SELECT
    b.id,
    c.name  AS customer_name,
    c.phone AS customer_phone,
    t.reg   AS tractor_reg,
    t.brand AS tractor_brand,
    b.service,
    b.hours,
    b.rate,
    b.amount,
    b.date,
    b.due,
    b.status,
    b.area,
    b.notes
FROM bills b
JOIN customers c ON b.customer_id = c.id
JOIN tractors  t ON b.tractor_id  = t.id;

CREATE OR REPLACE VIEW v_dashboard_stats AS
SELECT
    SUM(CASE WHEN status='Paid'    THEN amount ELSE 0 END) AS total_revenue,
    COUNT(CASE WHEN status='Pending' THEN 1 END)           AS pending_count,
    COUNT(CASE WHEN status='Overdue' THEN 1 END)           AS overdue_count,
    SUM(CASE WHEN status='Overdue' THEN amount ELSE 0 END) AS overdue_amount,
    COUNT(*)                                                AS total_bills
FROM bills;

-- ════════════════════════════════════════════════
COMMIT;
-- Schema complete. Tables: customers, tractors, bills
-- ════════════════════════════════════════════════
