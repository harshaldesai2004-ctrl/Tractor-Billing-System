package com.tractorbilling.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "bills")
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id", nullable = false)
    private Long customerId;

    @Column(name = "tractor_id", nullable = false)
    private Long tractorId;

    @Column(nullable = false)
    private String service;

    private Double hours;
    private Double rate;

    @Column(nullable = false)
    private Double amount;

    @Column(name = "paid_amount", nullable = false)
    private Double paidAmount = 0.0;   // How much the customer has actually paid

    @Column(nullable = false)
    private LocalDate date;

    private LocalDate due;

    @Column(nullable = false)
    private String status; // Paid | Pending | Overdue

    private Double area;

    @Column(length = 500)
    private String notes;

    // ── Getters & Setters ────────────────────
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public Long getTractorId() { return tractorId; }
    public void setTractorId(Long tractorId) { this.tractorId = tractorId; }

    public String getService() { return service; }
    public void setService(String service) { this.service = service; }

    public Double getHours() { return hours; }
    public void setHours(Double hours) { this.hours = hours; }

    public Double getRate() { return rate; }
    public void setRate(Double rate) { this.rate = rate; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public Double getPaidAmount() { return paidAmount != null ? paidAmount : 0.0; }
    public void setPaidAmount(Double paidAmount) { this.paidAmount = paidAmount != null ? paidAmount : 0.0; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public LocalDate getDue() { return due; }
    public void setDue(LocalDate due) { this.due = due; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Double getArea() { return area; }
    public void setArea(Double area) { this.area = area; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
