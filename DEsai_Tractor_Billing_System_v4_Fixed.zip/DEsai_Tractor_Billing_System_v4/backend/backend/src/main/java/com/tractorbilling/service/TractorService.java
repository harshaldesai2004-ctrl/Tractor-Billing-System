package com.tractorbilling.service;

import com.tractorbilling.model.Tractor;
import com.tractorbilling.repository.TractorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TractorService {

    @Autowired
    private TractorRepository tractorRepo;

    public List<Tractor> getAll() { return tractorRepo.findAll(); }

    public Optional<Tractor> getById(Long id) { return tractorRepo.findById(id); }

    public Tractor create(Tractor t) { return tractorRepo.save(t); }

    public Tractor update(Long id, Tractor updated) {
        return tractorRepo.findById(id).map(t -> {
            t.setReg(updated.getReg());
            t.setBrand(updated.getBrand());
            t.setModel(updated.getModel());
            t.setHp(updated.getHp());
            t.setYear(updated.getYear());
            t.setStatus(updated.getStatus());
            t.setOwner(updated.getOwner());
            t.setRate(updated.getRate());
            return tractorRepo.save(t);
        }).orElseThrow(() -> new RuntimeException("Tractor not found: " + id));
    }

    public void delete(Long id) { tractorRepo.deleteById(id); }

    public long activeCount() { return tractorRepo.findByStatus("Active").size(); }
}
