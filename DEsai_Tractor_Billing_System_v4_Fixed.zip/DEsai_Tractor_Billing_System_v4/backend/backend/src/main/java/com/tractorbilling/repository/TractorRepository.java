package com.tractorbilling.repository;

import com.tractorbilling.model.Tractor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TractorRepository extends JpaRepository<Tractor, Long> {
    List<Tractor> findByStatus(String status);
    boolean existsByReg(String reg);
}
