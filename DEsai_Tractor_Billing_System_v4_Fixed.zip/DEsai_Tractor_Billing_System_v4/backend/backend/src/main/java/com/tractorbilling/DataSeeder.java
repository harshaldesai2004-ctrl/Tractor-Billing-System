package com.tractorbilling;

import com.tractorbilling.model.Bill;
import com.tractorbilling.model.Customer;
import com.tractorbilling.model.Tractor;
import com.tractorbilling.repository.BillRepository;
import com.tractorbilling.repository.CustomerRepository;
import com.tractorbilling.repository.TractorRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner seedData(
            CustomerRepository customerRepo,
            TractorRepository tractorRepo,
            BillRepository billRepo) {

        return args -> {
            if (customerRepo.count() > 0) return; // skip if already seeded

            // ── Customers ────────────────────
            Customer[] customers = {
                makeCustomer("Ramesh Patel",    "9876543210", "Borsad",    "Anand",  12.0),
                makeCustomer("Suresh Desai",    "9765432109", "Khambhat",  "Anand",   8.0),
                makeCustomer("Mahesh Shah",     "9654321098", "Tarapur",   "Anand",  15.0),
                makeCustomer("Naresh Joshi",    "9543210987", "Petlad",    "Anand",   6.0),
                makeCustomer("Dinesh Solanki",  "9432109876", "Umreth",    "Anand",  10.0),
                makeCustomer("Kamlesh Parmar",  "9321098765", "Balasinor", "Kheda",   9.0),
            };
            customerRepo.save(customers[0]);
            customerRepo.save(customers[1]);
            customerRepo.save(customers[2]);
            customerRepo.save(customers[3]);
            customerRepo.save(customers[4]);
            customerRepo.save(customers[5]);

            // ── Tractors ─────────────────────
            Tractor t1 = makeTractor("GJ-05-AB-1234", "Mahindra",  "575 DI", 42, 2020, "Active",      "Raju Patel",    350.0);
            Tractor t2 = makeTractor("GJ-05-CD-5678", "John Deere","5310",   55, 2022, "Active",      "Suresh Sharma", 400.0);
            Tractor t3 = makeTractor("GJ-05-EF-9012", "Sonalika",  "DI 60",  60, 2021, "Maintenance", "Mukesh Verma",  450.0);
            tractorRepo.save(t1);
            tractorRepo.save(t2);
            tractorRepo.save(t3);

            // ── Bills ────────────────────────
            billRepo.save(makeBill(1L, 1L, "Ploughing",  8.0,  350.0, 2800.0, "2025-01-05", "2025-01-20", "Paid",    4.0, "North field"));
            billRepo.save(makeBill(2L, 2L, "Harvesting", 12.0, 400.0, 4800.0, "2025-01-12", "2025-01-27", "Paid",    6.0, ""));
            billRepo.save(makeBill(3L, 1L, "Sowing",      5.0, 300.0, 1500.0, "2025-02-03", "2025-02-18", "Pending", 3.0, "Wheat crop"));
            billRepo.save(makeBill(1L, 3L, "Transport",   3.0, 450.0, 1350.0, "2025-02-15", "2025-03-01", "Paid",    0.0, ""));
            billRepo.save(makeBill(4L, 2L, "Harrowing",   6.0, 350.0, 2100.0, "2025-03-08", "2025-03-23", "Overdue", 5.0, ""));
            billRepo.save(makeBill(2L, 1L, "Rotavation",  7.0, 380.0, 2660.0, "2025-03-18", "2025-04-02", "Paid",    3.5, ""));
            billRepo.save(makeBill(5L, 3L, "Ploughing",  10.0, 350.0, 3500.0, "2025-04-02", "2025-04-17", "Pending", 7.0, "Deep plough"));
            billRepo.save(makeBill(3L, 2L, "Harvesting", 14.0, 400.0, 5600.0, "2025-04-20", "2025-05-05", "Paid",    8.0, ""));
            billRepo.save(makeBill(6L, 1L, "Sowing",      4.0, 300.0, 1200.0, "2025-05-10", "2025-05-25", "Pending", 2.0, ""));
            billRepo.save(makeBill(4L, 3L, "Ploughing",   9.0, 350.0, 3150.0, "2025-05-22", "2025-06-06", "Overdue", 5.5, "Red soil"));
            billRepo.save(makeBill(1L, 2L, "Transport",   5.0, 450.0, 2250.0, "2025-06-05", "2025-06-20", "Paid",    0.0, ""));
            billRepo.save(makeBill(5L, 1L, "Harrowing",   8.0, 350.0, 2800.0, "2025-06-18", "2025-07-03", "Paid",    4.0, ""));
            billRepo.save(makeBill(2L, 3L, "Rotavation",  6.0, 380.0, 2280.0, "2025-07-08", "2025-07-23", "Paid",    3.0, ""));
            billRepo.save(makeBill(6L, 2L, "Ploughing",  11.0, 350.0, 3850.0, "2025-08-01", "2025-08-16", "Pending", 6.0, ""));
            billRepo.save(makeBill(3L, 1L, "Harvesting", 15.0, 400.0, 6000.0, "2025-08-25", "2025-09-09", "Paid",    9.0, "Good yield"));

            System.out.println("✅ Database seeded with sample data.");
        };
    }

    private Customer makeCustomer(String name, String phone, String village, String district, double land) {
        Customer c = new Customer();
        c.setName(name); c.setPhone(phone);
        c.setVillage(village); c.setDistrict(district);
        c.setLand(land);
        return c;
    }

    private Tractor makeTractor(String reg, String brand, String model, int hp, int year, String status, String owner, double rate) {
        Tractor t = new Tractor();
        t.setReg(reg); t.setBrand(brand); t.setModel(model);
        t.setHp(hp); t.setYear(year); t.setStatus(status);
        t.setOwner(owner); t.setRate(rate);
        return t;
    }

    private Bill makeBill(long custId, long tractorId, String service, double hours, double rate,
                          double amount, String date, String due, String status, double area, String notes) {
        Bill b = new Bill();
        b.setCustomerId(custId); b.setTractorId(tractorId);
        b.setService(service); b.setHours(hours); b.setRate(rate);
        b.setAmount(amount);
        // Set paidAmount: full amount if Paid, 0 if Pending/Overdue
        b.setPaidAmount("Paid".equals(status) ? amount : 0.0);
        b.setDate(LocalDate.parse(date));
        b.setDue(LocalDate.parse(due)); b.setStatus(status);
        b.setArea(area); b.setNotes(notes);
        return b;
    }
}
