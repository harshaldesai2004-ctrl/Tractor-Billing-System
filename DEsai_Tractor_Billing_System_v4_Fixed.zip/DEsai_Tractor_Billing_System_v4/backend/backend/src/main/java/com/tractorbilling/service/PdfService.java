package com.tractorbilling.service;

import com.tractorbilling.model.Bill;
import com.tractorbilling.model.Customer;
import com.tractorbilling.model.Tractor;
import com.tractorbilling.repository.BillRepository;
import com.tractorbilling.repository.CustomerRepository;
import com.tractorbilling.repository.TractorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * PdfService — generates invoice PDFs and daily reports as styled HTML.
 *
 * FIXES applied in this version:
 *  1. Invoice now clearly separates Paid Amount vs Pending Amount.
 *     - Paid bills  → show "Amount Paid" in green.
 *     - Pending bills → show "Total Due" + "Amount Paid (₹0)" + "Pending Amount" in orange.
 *     - Overdue bills → show "Total Due" + "Amount Paid (₹0)" + "Overdue Amount" in red.
 *  2. Added Daily Report (generateDailyReport) with:
 *     - Summary cards: total bills, total paid, total pending, total overdue for the day.
 *     - Table of all bills for the selected date.
 *  3. Added Summary Report with pending + overdue totals.
 */
@Service
public class PdfService {

    @Autowired private BillRepository    billRepo;
    @Autowired private CustomerRepository customerRepo;
    @Autowired private TractorRepository  tractorRepo;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd MMM yyyy");

    // ─── Single Invoice ────────────────────────────────────────
    public byte[] generateInvoice(Long billId) {
        Bill bill = billRepo.findById(billId)
                .orElseThrow(() -> new RuntimeException("Bill not found: " + billId));
        Customer c = customerRepo.findById(bill.getCustomerId()).orElse(null);
        Tractor  t = tractorRepo.findById(bill.getTractorId()).orElse(null);
        String html = wrapPage(buildInvoiceHtml(bill, c, t, false), "Invoice #" + billId);
        return html.getBytes(StandardCharsets.UTF_8);
    }

    // ─── Bulk / Filtered Report ────────────────────────────────
    public byte[] generateBulkReport(String status, Long customerId) {
        List<Bill> bills;
        if (customerId != null) {
            bills = billRepo.findByCustomerId(customerId);
        } else if (status != null && !status.isBlank()) {
            bills = billRepo.findByStatus(status);
        } else {
            bills = billRepo.findAll();
        }

        double totalPaid    = bills.stream().filter(b -> "Paid".equals(b.getStatus())).mapToDouble(b -> nvl(b.getAmount())).sum();
        double totalPending = bills.stream().filter(b -> "Pending".equals(b.getStatus())).mapToDouble(b -> nvl(b.getAmount())).sum();
        double totalOverdue = bills.stream().filter(b -> "Overdue".equals(b.getStatus())).mapToDouble(b -> nvl(b.getAmount())).sum();

        String title = status != null && !status.isBlank() ? status + " Bills Report" : "All Bills Report";

        StringBuilder sb = new StringBuilder();
        sb.append(buildSummaryBanner(bills.size(), totalPaid, totalPending, totalOverdue, null));
        for (int i = 0; i < bills.size(); i++) {
            Bill bill = bills.get(i);
            Customer c = customerRepo.findById(bill.getCustomerId()).orElse(null);
            Tractor  t = tractorRepo.findById(bill.getTractorId()).orElse(null);
            sb.append(buildInvoiceHtml(bill, c, t, i < bills.size() - 1));
        }

        return wrapPage(sb.toString(), title).getBytes(StandardCharsets.UTF_8);
    }

    // ─── Daily Report ─────────────────────────────────────────
    public byte[] generateDailyReport(LocalDate date) {
        List<Bill> bills = billRepo.findByDate(date);

        double totalPaid    = bills.stream().filter(b -> "Paid".equals(b.getStatus())).mapToDouble(b -> nvl(b.getAmount())).sum();
        double totalPending = bills.stream().filter(b -> "Pending".equals(b.getStatus())).mapToDouble(b -> nvl(b.getAmount())).sum();
        double totalOverdue = bills.stream().filter(b -> "Overdue".equals(b.getStatus())).mapToDouble(b -> nvl(b.getAmount())).sum();

        String title = "Daily Report – " + date.format(FMT);

        StringBuilder sb = new StringBuilder();
        sb.append(buildSummaryBanner(bills.size(), totalPaid, totalPending, totalOverdue, date));

        if (bills.isEmpty()) {
            sb.append("<div style='text-align:center;padding:40px;color:#888;font-size:16px;'>No bills found for this date.</div>");
        } else {
            sb.append(buildDailyTable(bills));
        }

        return wrapPage(sb.toString(), title).getBytes(StandardCharsets.UTF_8);
    }

    // ─── HTML: Summary Banner ──────────────────────────────────
    private String buildSummaryBanner(int count, double paid, double pending, double overdue, LocalDate date) {
        String dateLabel = date != null ? "Date: " + date.format(FMT) : "All Dates";
        return """
            <div class="summary-banner">
              <div class="summary-title">📊 %s &nbsp;|&nbsp; %d Bill(s)</div>
              <div class="summary-cards">
                <div class="scard scard-paid">
                  <div class="scard-label">✅ Total Paid</div>
                  <div class="scard-amount">₹%s</div>
                </div>
                <div class="scard scard-pending">
                  <div class="scard-label">⏳ Total Pending</div>
                  <div class="scard-amount">₹%s</div>
                </div>
                <div class="scard scard-overdue">
                  <div class="scard-label">🔴 Total Overdue</div>
                  <div class="scard-amount">₹%s</div>
                </div>
              </div>
            </div>
            """.formatted(dateLabel, count, fmt(paid), fmt(pending), fmt(overdue));
    }

    // ─── HTML: Daily Table ─────────────────────────────────────
    private String buildDailyTable(List<Bill> bills) {
        StringBuilder rows = new StringBuilder();
        for (Bill b : bills) {
            Customer c = customerRepo.findById(b.getCustomerId()).orElse(null);
            String name   = c != null ? c.getName() : "—";
            String phone  = c != null ? c.getPhone() : "—";
            String color  = statusColor(b.getStatus());
            String badge  = "<span style='color:%s;font-weight:700;background:%s20;padding:2px 10px;border-radius:20px;font-size:11px;'>%s</span>"
                    .formatted(color, color, b.getStatus());
            String dueDate = b.getDue() != null ? b.getDue().format(FMT) : "—";

            // Paid / Pending breakdown in table — use real paidAmount
            double paidAmt    = nvl(b.getPaidAmount());
            double pendingAmt = "Pending".equals(b.getStatus()) || "Overdue".equals(b.getStatus())
                    ? Math.max(0, nvl(b.getAmount()) - paidAmt) : 0;
            double overdueAmt = "Overdue".equals(b.getStatus()) ? Math.max(0, nvl(b.getAmount()) - paidAmt) : 0;
            if ("Pending".equals(b.getStatus())) overdueAmt = 0; // don't double-count

            rows.append("""
                <tr>
                  <td>#%04d</td><td>%s</td><td>%s</td><td>%s</td>
                  <td>%s</td><td>%s</td>
                  <td style='color:#2e7d32;font-weight:600;'>%s</td>
                  <td style='color:#e65100;font-weight:600;'>%s</td>
                  <td style='color:#c62828;font-weight:600;'>%s</td>
                  <td>%s</td><td>%s</td>
                </tr>
                """.formatted(
                    b.getId(), name, phone, b.getService(),
                    fmt(b.getAmount()), dueDate,
                    paidAmt > 0 ? "₹" + fmt(paidAmt) : "—",
                    pendingAmt > 0 ? "₹" + fmt(pendingAmt) : "—",
                    overdueAmt > 0 ? "₹" + fmt(overdueAmt) : "—",
                    badge, b.getNotes() != null ? escHtml(b.getNotes()) : "—"
            ));
        }

        return """
            <div class="daily-table-wrap">
              <table class="daily-table">
                <thead>
                  <tr>
                    <th>Bill #</th><th>Customer</th><th>Phone</th><th>Service</th>
                    <th>Total (₹)</th><th>Due Date</th>
                    <th>Paid (₹)</th><th>Pending (₹)</th><th>Overdue (₹)</th>
                    <th>Status</th><th>Notes</th>
                  </tr>
                </thead>
                <tbody>%s</tbody>
              </table>
            </div>
            """.formatted(rows.toString());
    }

    // ─── HTML: Single Invoice Card ─────────────────────────────
    private String buildInvoiceHtml(Bill bill, Customer customer, Tractor tractor, boolean pageBreak) {
        String customerName    = customer != null ? customer.getName()    : "—";
        String customerPhone   = customer != null ? customer.getPhone()   : "—";
        String customerVillage = customer != null ? customer.getVillage() : "—";
        String customerDistrict= customer != null ? customer.getDistrict(): "—";
        String tractorReg      = tractor  != null ? tractor.getReg()      : "—";
        String tractorBrand    = tractor  != null ? tractor.getBrand()    : "—";
        String tractorModel    = tractor  != null ? tractor.getModel()    : "—";

        String billDate  = bill.getDate() != null ? bill.getDate().format(FMT) : "—";
        String dueDate   = bill.getDue()  != null ? bill.getDue().format(FMT)  : "—";
        String color     = statusColor(bill.getStatus());
        String pageBreakCss = pageBreak ? "page-break-after:always;" : "";
        String billNumber   = String.format("#%04d", bill.getId());

        double totalAmount = nvl(bill.getAmount());
        double paidAmount  = nvl(bill.getPaidAmount());
        double pendingAmount = Math.max(0, totalAmount - paidAmount);

        // ── Payment breakdown section ──
        // Uses the real paidAmount stored on the bill for all statuses
        String paymentSection;
        if ("Paid".equals(bill.getStatus())) {
            paymentSection = """
                <div class="inv-totals">
                  <div class="total-row"><span>Subtotal</span><span>₹%s</span></div>
                  <div class="total-row total-paid"><span>✅ Amount Paid</span><span>₹%s</span></div>
                  <div class="total-row"><span style="color:#2e7d32;">Balance Due</span><span style="color:#2e7d32;">₹0.00</span></div>
                </div>
                """.formatted(fmt(totalAmount), fmt(paidAmount));
        } else if ("Pending".equals(bill.getStatus())) {
            paymentSection = """
                <div class="inv-totals">
                  <div class="total-row"><span>Total Invoice Amount</span><span>₹%s</span></div>
                  <div class="total-row"><span>✅ Amount Paid</span><span style="color:#2e7d32;font-weight:700;">₹%s</span></div>
                  <div class="total-row total-pending"><span>⏳ Pending Amount</span><span>₹%s</span></div>
                </div>
                """.formatted(fmt(totalAmount), fmt(paidAmount), fmt(pendingAmount));
        } else { // Overdue
            paymentSection = """
                <div class="inv-totals">
                  <div class="total-row"><span>Total Invoice Amount</span><span>₹%s</span></div>
                  <div class="total-row"><span>✅ Amount Paid</span><span style="color:#2e7d32;font-weight:700;">₹%s</span></div>
                  <div class="total-row total-overdue"><span>🔴 Overdue Amount</span><span>₹%s</span></div>
                </div>
                """.formatted(fmt(totalAmount), fmt(paidAmount), fmt(pendingAmount));
        }

        String notes = bill.getNotes() != null && !bill.getNotes().isBlank()
                ? "<div class=\"inv-notes\"><b>Notes:</b> " + escHtml(bill.getNotes()) + "</div>"
                : "";

        return """
            <div class="invoice" style="%s">
              <div class="inv-header">
                <div class="inv-logo">
                  <div class="inv-logo-title">Desai Tractor</div>
                  <div class="inv-logo-sub">Billing System</div>
                </div>
                <div class="inv-meta">
                  <div class="inv-number">INVOICE %s</div>
                  <div class="inv-date">Date: %s</div>
                  <div class="inv-due">Due: %s</div>
                  <div class="inv-status" style="color:%s;font-weight:700;margin-top:6px;">%s</div>
                </div>
              </div>

              <div class="inv-parties">
                <div class="inv-party">
                  <div class="party-label">BILLED TO</div>
                  <div class="party-name">%s</div>
                  <div class="party-detail">📞 %s</div>
                  <div class="party-detail">📍 %s, %s</div>
                </div>
                <div class="inv-party">
                  <div class="party-label">TRACTOR DETAILS</div>
                  <div class="party-name">%s</div>
                  <div class="party-detail">%s %s</div>
                </div>
              </div>

              <table class="inv-table">
                <thead>
                  <tr>
                    <th>Service</th><th>Field Area (acres)</th>
                    <th>Hours</th><th>Rate/hr (₹)</th><th>Amount (₹)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>%s</td>
                    <td>%s</td>
                    <td>%s</td>
                    <td>%s</td>
                    <td class="amount-cell">₹%s</td>
                  </tr>
                </tbody>
              </table>

              %s
              %s

              <div class="inv-footer">
                Desai Tractor Billing System &nbsp;|&nbsp; Generated on %s
              </div>
            </div>
            """.formatted(
                pageBreakCss,
                billNumber, billDate, dueDate, color, bill.getStatus(),
                customerName, customerPhone, customerVillage, customerDistrict,
                tractorReg, tractorBrand, tractorModel,
                bill.getService(),
                bill.getArea() != null ? bill.getArea() + " ac" : "—",
                bill.getHours() != null ? bill.getHours().toString() : "—",
                bill.getRate()  != null ? "₹" + fmt(bill.getRate())  : "—",
                fmt(totalAmount),
                paymentSection,
                notes,
                LocalDate.now().format(FMT)
        );
    }

    // ─── Page wrapper ──────────────────────────────────────────
    private String wrapPage(String body, String title) {
        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
              <meta charset="UTF-8">
              <title>%s</title>
              <style>
                @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&display=swap');
                * { box-sizing:border-box; margin:0; padding:0; }
                body { font-family:'DM Sans',Arial,sans-serif; background:#f5f5f0; color:#1a1a1a; font-size:13px; }
                @media print {
                  body { background:#fff; }
                  .no-print { display:none !important; }
                  .invoice { box-shadow:none !important; margin:0 !important; }
                  .daily-table-wrap { overflow:visible; }
                }
                /* ── Print bar ── */
                .print-bar {
                  background:#0d0f0a; color:#e8ead8;
                  padding:12px 32px; display:flex; align-items:center; justify-content:space-between;
                  position:sticky; top:0; z-index:100;
                }
                .print-bar-title { font-size:14px; font-weight:600; letter-spacing:1px; color:#8fba2e; }
                .print-btn {
                  background:#8fba2e; color:#0d0f0a; border:none; border-radius:6px;
                  padding:8px 20px; font-size:13px; font-weight:700; cursor:pointer; letter-spacing:0.5px;
                }
                .print-btn:hover { background:#c8e86a; }
                /* ── Layout ── */
                .invoice-wrap { max-width:860px; margin:32px auto; padding:0 16px; }
                /* ── Summary Banner ── */
                .summary-banner {
                  background:#fff; border-radius:10px;
                  box-shadow:0 4px 20px rgba(0,0,0,.08);
                  padding:24px 32px; margin-bottom:28px;
                }
                .summary-title { font-size:16px; font-weight:700; color:#333; margin-bottom:18px; }
                .summary-cards { display:flex; gap:16px; flex-wrap:wrap; }
                .scard {
                  flex:1; min-width:160px; border-radius:8px;
                  padding:16px 20px; text-align:center;
                }
                .scard-label { font-size:11px; font-weight:700; letter-spacing:1px; text-transform:uppercase; margin-bottom:8px; }
                .scard-amount { font-size:22px; font-weight:800; }
                .scard-paid    { background:#e8f5e9; color:#2e7d32; }
                .scard-pending { background:#fff3e0; color:#e65100; }
                .scard-overdue { background:#ffebee; color:#c62828; }
                /* ── Invoice card ── */
                .invoice {
                  background:#fff; border-radius:8px;
                  box-shadow:0 4px 24px rgba(0,0,0,.10);
                  padding:40px 48px; margin-bottom:32px;
                }
                .inv-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:32px; border-bottom:2px solid #8fba2e; padding-bottom:20px; }
                .inv-logo-title { font-size:28px; font-weight:800; color:#5a8c1a; letter-spacing:1px; }
                .inv-logo-sub { font-size:10px; color:#888; letter-spacing:3px; text-transform:uppercase; margin-top:2px; }
                .inv-meta { text-align:right; }
                .inv-number { font-size:22px; font-weight:800; color:#1a1a1a; margin-bottom:4px; }
                .inv-date,.inv-due { font-size:12px; color:#555; }
                .inv-parties { display:flex; gap:48px; margin-bottom:28px; }
                .inv-party { flex:1; }
                .party-label { font-size:10px; letter-spacing:2px; text-transform:uppercase; color:#8fba2e; font-weight:700; margin-bottom:8px; }
                .party-name { font-size:16px; font-weight:700; margin-bottom:4px; }
                .party-detail { font-size:12px; color:#555; margin-bottom:2px; }
                /* ── Invoice table ── */
                .inv-table { width:100%%; border-collapse:collapse; margin-bottom:20px; }
                .inv-table th { background:#f0f4e8; font-size:11px; letter-spacing:1px; text-transform:uppercase; color:#5a8c1a; padding:10px 14px; text-align:left; border-bottom:2px solid #d4e8a0; }
                .inv-table td { padding:12px 14px; border-bottom:1px solid #eee; font-size:13px; }
                .amount-cell { font-weight:700; font-size:15px; }
                /* ── Totals ── */
                .inv-totals { display:flex; flex-direction:column; align-items:flex-end; gap:6px; margin-bottom:20px; }
                .total-row { display:flex; gap:48px; font-size:13px; color:#555; }
                .total-row span:last-child { min-width:130px; text-align:right; }
                .total-paid    { font-size:17px; font-weight:800; color:#2e7d32; border-top:2px solid #2e7d32; padding-top:8px; margin-top:4px; }
                .total-pending { font-size:17px; font-weight:800; color:#e65100; border-top:2px solid #e65100; padding-top:8px; margin-top:4px; }
                .total-overdue { font-size:17px; font-weight:800; color:#c62828; border-top:2px solid #c62828; padding-top:8px; margin-top:4px; }
                .inv-notes { background:#f9fbf5; border-left:3px solid #8fba2e; padding:12px 16px; border-radius:4px; font-size:12px; color:#444; margin-bottom:20px; }
                .inv-footer { text-align:center; font-size:11px; color:#aaa; border-top:1px solid #eee; padding-top:16px; }
                /* ── Daily table ── */
                .daily-table-wrap { overflow-x:auto; margin-bottom:32px; }
                .daily-table { width:100%%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,.06); }
                .daily-table th { background:#5a8c1a; color:#fff; font-size:11px; letter-spacing:.8px; text-transform:uppercase; padding:12px 14px; text-align:left; white-space:nowrap; }
                .daily-table td { padding:10px 14px; border-bottom:1px solid #f0f0f0; font-size:12px; vertical-align:middle; }
                .daily-table tr:hover td { background:#f9fbf5; }
              </style>
            </head>
            <body>
              <div class="print-bar no-print">
                <div class="print-bar-title">🚜 Desai Tractor – %s</div>
                <button class="print-btn" onclick="window.print()">🖨️ Print / Save PDF</button>
              </div>
              <div class="invoice-wrap">%s</div>
            </body>
            </html>
            """.formatted(title, title, body);
    }

    // ─── Helpers ───────────────────────────────────────────────
    private String statusColor(String status) {
        return switch (status) {
            case "Paid"    -> "#2e7d32";
            case "Overdue" -> "#c62828";
            default        -> "#e65100";
        };
    }

    private double nvl(Double d) { return d != null ? d : 0.0; }

    private String fmt(double amount) { return String.format("%,.2f", amount); }
    private String fmt(Double amount)  { return fmt(amount != null ? amount : 0.0); }

    private String escHtml(String s) {
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
}
