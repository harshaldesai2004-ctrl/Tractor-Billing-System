package com.tractorbilling.repository;

import com.tractorbilling.model.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {

    List<Bill> findByStatus(String status);

    List<Bill> findByCustomerId(Long customerId);

    List<Bill> findByTractorId(Long tractorId);

    // Daily bills
    List<Bill> findByDate(LocalDate date);

    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.status = 'Paid'")
    Double totalRevenue();

    @Query("SELECT COUNT(b) FROM Bill b WHERE b.status = 'Pending'")
    Long pendingCount();

    @Query("SELECT COUNT(b) FROM Bill b WHERE b.status = 'Overdue'")
    Long overdueCount();

    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.status = 'Overdue'")
    Double overdueAmount();

    // Real pending = total - paidAmount for non-Paid bills
    @Query("SELECT SUM(b.amount - b.paidAmount) FROM Bill b WHERE b.status = 'Pending'")
    Double pendingAmount();

    @Query("SELECT SUM(b.amount - b.paidAmount) FROM Bill b WHERE b.status = 'Overdue'")
    Double realOverdueAmount();

    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.status = 'Paid' AND b.date = :date")
    Double dailyPaidAmount(LocalDate date);

    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.status = 'Pending' AND b.date = :date")
    Double dailyPendingAmount(LocalDate date);

    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.status = 'Overdue' AND b.date = :date")
    Double dailyOverdueAmount(LocalDate date);

    @Query("SELECT COUNT(b) FROM Bill b WHERE b.date = :date")
    Long dailyBillCount(LocalDate date);
}
