package com.tractorbilling.service;

import com.tractorbilling.model.Customer;
import com.tractorbilling.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepo;

    public List<Customer> getAll() { return customerRepo.findAll(); }

    public Optional<Customer> getById(Long id) { return customerRepo.findById(id); }

    public Customer create(Customer c) { return customerRepo.save(c); }

    public Customer update(Long id, Customer updated) {
        return customerRepo.findById(id).map(c -> {
            c.setName(updated.getName());
            c.setPhone(updated.getPhone());
            c.setVillage(updated.getVillage());
            c.setDistrict(updated.getDistrict());
            c.setAadhar(updated.getAadhar());
            c.setLand(updated.getLand());
            return customerRepo.save(c);
        }).orElseThrow(() -> new RuntimeException("Customer not found: " + id));
    }

    public void delete(Long id) { customerRepo.deleteById(id); }
}
