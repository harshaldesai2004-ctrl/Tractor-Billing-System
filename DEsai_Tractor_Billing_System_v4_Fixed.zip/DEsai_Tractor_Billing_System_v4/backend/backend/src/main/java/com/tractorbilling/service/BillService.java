package com.tractorbilling.service;

import com.tractorbilling.model.Bill;
import com.tractorbilling.repository.BillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BillService {

    @Autowired
    private BillRepository billRepo;

    public List<Bill> getAll() { return billRepo.findAll(); }

    public Optional<Bill> getById(Long id) { return billRepo.findById(id); }

    public Bill create(Bill bill) { return billRepo.save(bill); }

    public Bill update(Long id, Bill updated) {
        return billRepo.findById(id).map(b -> {
            b.setCustomerId(updated.getCustomerId());
            b.setTractorId(updated.getTractorId());
            b.setService(updated.getService());
            b.setHours(updated.getHours());
            b.setRate(updated.getRate());
            b.setAmount(updated.getAmount());
            b.setPaidAmount(updated.getPaidAmount());
            b.setDate(updated.getDate());
            b.setDue(updated.getDue());
            b.setStatus(updated.getStatus());
            b.setArea(updated.getArea());
            b.setNotes(updated.getNotes());
            return billRepo.save(b);
        }).orElseThrow(() -> new RuntimeException("Bill not found: " + id));
    }

    public void delete(Long id) { billRepo.deleteById(id); }

    public List<Bill> getByStatus(String status) { return billRepo.findByStatus(status); }

    public List<Bill> getByCustomer(Long customerId) { return billRepo.findByCustomerId(customerId); }

    public List<Bill> getByDate(LocalDate date) { return billRepo.findByDate(date); }

    // Dashboard stats
    public Double totalRevenue() { Double r = billRepo.totalRevenue(); return r != null ? r : 0.0; }
    public Long pendingCount()   { return billRepo.pendingCount(); }
    public Long overdueCount()   { return billRepo.overdueCount(); }
    public Double overdueAmount(){ Double r = billRepo.overdueAmount(); return r != null ? r : 0.0; }
    public Double pendingAmount(){ Double r = billRepo.pendingAmount(); return r != null ? r : 0.0; }
}
