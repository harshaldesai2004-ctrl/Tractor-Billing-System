package com.tractorbilling.controller;

import com.tractorbilling.model.Tractor;
import com.tractorbilling.service.TractorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tractors")
public class TractorController {

    @Autowired
    private TractorService tractorService;

    @GetMapping
    public List<Tractor> getAll() { return tractorService.getAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Tractor> getById(@PathVariable Long id) {
        return tractorService.getById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Tractor> create(@RequestBody Tractor tractor) {
        return ResponseEntity.ok(tractorService.create(tractor));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Tractor> update(@PathVariable Long id, @RequestBody Tractor tractor) {
        try {
            return ResponseEntity.ok(tractorService.update(id, tractor));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable Long id) {
        tractorService.delete(id);
        return ResponseEntity.ok(Map.of("deleted", true, "id", id));
    }
}
