package com.tractorbilling.controller;

import com.tractorbilling.model.Bill;
import com.tractorbilling.service.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bills")
public class BillController {

    @Autowired
    private BillService billService;

    @GetMapping
    public List<Bill> getAll() { return billService.getAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Bill> getById(@PathVariable Long id) {
        return billService.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/status/{status}")
    public List<Bill> getByStatus(@PathVariable String status) { return billService.getByStatus(status); }

    @GetMapping("/customer/{customerId}")
    public List<Bill> getByCustomer(@PathVariable Long customerId) { return billService.getByCustomer(customerId); }

    @GetMapping("/date/{date}")
    public List<Bill> getByDate(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return billService.getByDate(date);
    }

    @PostMapping
    public ResponseEntity<Bill> create(@RequestBody Bill bill) { return ResponseEntity.ok(billService.create(bill)); }

    @PutMapping("/{id}")
    public ResponseEntity<Bill> update(@PathVariable Long id, @RequestBody Bill bill) {
        try { return ResponseEntity.ok(billService.update(id, bill)); }
        catch (RuntimeException e) { return ResponseEntity.notFound().build(); }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable Long id) {
        billService.delete(id);
        return ResponseEntity.ok(Map.of("deleted", true, "id", id));
    }

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStats() {
        return ResponseEntity.ok(Map.of(
                "totalRevenue",  billService.totalRevenue(),
                "pendingCount",  billService.pendingCount(),
                "pendingAmount", billService.pendingAmount(),
                "overdueCount",  billService.overdueCount(),
                "overdueAmount", billService.overdueAmount()
        ));
    }
}
