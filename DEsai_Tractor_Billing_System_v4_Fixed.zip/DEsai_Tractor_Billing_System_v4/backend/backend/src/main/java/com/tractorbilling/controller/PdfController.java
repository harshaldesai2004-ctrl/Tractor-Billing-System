package com.tractorbilling.controller;

import com.tractorbilling.service.PdfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

/**
 * PdfController — invoice & report endpoints.
 *
 * GET /api/pdf/invoice/{id}            → single bill invoice
 * GET /api/pdf/invoice/{id}/download   → download single invoice
 * GET /api/pdf/report                  → bulk report (all / filtered)
 * GET /api/pdf/report?status=Pending   → filtered by status
 * GET /api/pdf/report?customerId=5     → filtered by customer
 * GET /api/pdf/daily                   → daily report for today
 * GET /api/pdf/daily?date=2025-03-31   → daily report for specific date
 */
@RestController
@RequestMapping("/api/pdf")
public class PdfController {

    @Autowired
    private PdfService pdfService;

    // ── Single invoice ───────────────────────────────────────
    @GetMapping(value = "/invoice/{id}", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<byte[]> getInvoice(@PathVariable Long id) {
        byte[] html = pdfService.generateInvoice(id);
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.TEXT_HTML);
        h.add("Content-Disposition", "inline; filename=\"invoice-" + id + ".html\"");
        return ResponseEntity.ok().headers(h).body(html);
    }

    @GetMapping(value = "/invoice/{id}/download", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<byte[]> downloadInvoice(@PathVariable Long id) {
        byte[] html = pdfService.generateInvoice(id);
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.TEXT_HTML);
        h.add("Content-Disposition", "attachment; filename=\"invoice-" + id + ".html\"");
        return ResponseEntity.ok().headers(h).body(html);
    }

    // ── Bulk report ───────────────────────────────────────────
    @GetMapping(value = "/report", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<byte[]> getBulkReport(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Long customerId) {
        byte[] html = pdfService.generateBulkReport(status, customerId);
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.TEXT_HTML);
        h.add("Content-Disposition", "inline; filename=\"bills-report.html\"");
        return ResponseEntity.ok().headers(h).body(html);
    }

    // ── Daily report ─────────────────────────────────────────
    @GetMapping(value = "/daily", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<byte[]> getDailyReport(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        LocalDate reportDate = date != null ? date : LocalDate.now();
        byte[] html = pdfService.generateDailyReport(reportDate);
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.TEXT_HTML);
        h.add("Content-Disposition", "inline; filename=\"daily-report-" + reportDate + ".html\"");
        return ResponseEntity.ok().headers(h).body(html);
    }
}
