package com.tractorbilling.model;

import jakarta.persistence.*;

@Entity
@Table(name = "tractors")
public class Tractor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String reg;          // Registration number

    private String brand;
    private String model;
    private Integer hp;
    private Integer year;

    @Column(nullable = false)
    private String status;       // Active | Maintenance | Idle

    private String owner;
    private Double rate;         // Rate per hour

    // ── Getters & Setters ────────────────────
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getReg() { return reg; }
    public void setReg(String reg) { this.reg = reg; }

    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public Integer getHp() { return hp; }
    public void setHp(Integer hp) { this.hp = hp; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }

    public Double getRate() { return rate; }
    public void setRate(Double rate) { this.rate = rate; }
}
