# 🚜 Desai Tractor Billing System — Tractor Billing System

A full-stack Tractor Billing System with a dark industrial UI, interactive charts, and complete CRUD operations.

---

## 📁 Project Structure

```
tractor-billing/
├── frontend/
│   └── index.html          ← Single-file frontend (HTML + CSS + JS)
└── backend/
    ├── pom.xml              ← Maven build file
    ├── schema.sql           ← MySQL schema + seed data
    └── src/main/
        ├── java/com/tractorbilling/
        │   ├── TractorBillingApplication.java
        │   ├── CorsConfig.java
        │   ├── DataSeeder.java
        │   ├── model/       (Bill, Tractor, Customer)
        │   ├── repository/  (JPA Repositories)
        │   ├── service/     (Business Logic)
        │   └── controller/  (REST APIs)
        └── resources/
            └── application.properties
```

---

## 🚀 Quick Start (Demo Mode — No Backend Needed)

1. Open `frontend/index.html` directly in your browser.
2. The app runs in **Demo Mode** with local in-memory data.
3. All CRUD operations work — data persists within the session.

---

## 🛠️ Full Stack Setup

### Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.0+ (optional — H2 in-memory DB works by default)
- A modern web browser

### 1. Backend (Spring Boot)

#### Option A — H2 In-Memory (No MySQL needed)
```bash
cd backend
mvn spring-boot:run
```
Server starts at `http://localhost:8080`
- H2 Console: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:tractordb`

#### Option B — MySQL
1. Run the SQL schema:
   ```bash
   mysql -u root -p < backend/schema.sql
   ```
2. Edit `application.properties`:
   - Comment out H2 lines
   - Uncomment MySQL lines and set your credentials
3. Start the server:
   ```bash
   cd backend
   mvn spring-boot:run
   ```

### 2. Frontend
Open `frontend/index.html` in your browser.
- The app auto-detects if the backend is running.
- If backend is up → uses real API data.
- If backend is down → falls back to demo mode.

---

## 🔌 REST API Reference

### Bills
| Method | Endpoint               | Description         |
|--------|------------------------|---------------------|
| GET    | /api/bills             | Get all bills       |
| GET    | /api/bills/{id}        | Get bill by ID      |
| POST   | /api/bills             | Create new bill     |
| PUT    | /api/bills/{id}        | Update bill         |
| DELETE | /api/bills/{id}        | Delete bill         |
| GET    | /api/bills/stats       | Dashboard stats     |
| GET    | /api/bills/status/{s}  | Filter by status    |

### Tractors
| Method | Endpoint               | Description         |
|--------|------------------------|---------------------|
| GET    | /api/tractors          | Get all tractors    |
| GET    | /api/tractors/{id}     | Get tractor by ID   |
| POST   | /api/tractors          | Add tractor         |
| PUT    | /api/tractors/{id}     | Update tractor      |
| DELETE | /api/tractors/{id}     | Delete tractor      |

### Customers
| Method | Endpoint               | Description         |
|--------|------------------------|---------------------|
| GET    | /api/customers         | Get all customers   |
| GET    | /api/customers/{id}    | Get customer by ID  |
| POST   | /api/customers         | Add customer        |
| PUT    | /api/customers/{id}    | Update customer     |
| DELETE | /api/customers/{id}    | Delete customer     |

### Health
| Method | Endpoint    | Description   |
|--------|-------------|---------------|
| GET    | /api/health | Health check  |

---

## ✨ Features

- **Dashboard** — Revenue stats, 4 live charts (bar, doughnut, horizontal bar, bar)
- **Billing** — Full CRUD, search, filter by status/month, CSV export
- **Tractors** — Fleet management with status tracking (Active/Maintenance/Idle)
- **Customers** — Customer management with billing history
- **Reports** — Quarterly revenue, tractor utilization, monthly summary table
- **Dark UI** — Industrial-agricultural aesthetic with green accent (#8fba2e)
- **Auto-fallback** — Works offline in demo mode if backend is unavailable

---

## 🗄️ Database Schema

```sql
customers  (id, name, phone, village, district, aadhar, land)
tractors   (id, reg, brand, model, hp, year, status, owner, rate)
bills      (id, customer_id, tractor_id, service, hours, rate, amount, 
            date, due, status, area, notes)
```

---

## 🏗️ Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Frontend  | HTML5, CSS3, Vanilla JS, Chart.js |
| Backend   | Java 17, Spring Boot 3.2          |
| ORM       | Spring Data JPA / Hibernate       |
| Database  | MySQL 8 (H2 for dev/demo)         |
| Build     | Maven                             |
