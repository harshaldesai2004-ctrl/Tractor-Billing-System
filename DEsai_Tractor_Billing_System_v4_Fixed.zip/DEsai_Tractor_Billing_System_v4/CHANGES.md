# Desai Tractor Billing System — Change Log

## v3.0 — Paid Amount & PDF Billing Fix (Latest)

### 🐛 Root Cause: paidAmount Was Never Saved
The bill form had an "Amount Paid" field but it was **never included** in the data
sent to the backend. The database also had no `paid_amount` column, so partial
payments were completely lost on every save.

### Fixes Applied

**1. `schema.sql`** — Added `paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0` column to
`bills` table. Updated all seed INSERT statements to include `paid_amount`.

**2. `Bill.java`** — Added `paidAmount` field with `@Column(name="paid_amount")`,
getter, and setter.

**3. `BillService.java`** — `update()` now copies `paidAmount` from updated bill.

**4. `BillRepository.java`** — `pendingAmount()` now returns `SUM(amount - paidAmount)`
for Pending bills (real balance). Added `realOverdueAmount()` for Overdue bills.

**5. `PdfService.java`** — Invoice PDF now shows:
- `Total Invoice Amount` = full bill amount
- `✅ Amount Paid` = actual saved paidAmount (green)
- `⏳ Pending / 🔴 Overdue Amount` = total − paidAmount
Previously always showed "Amount Paid: ₹0" for all non-Paid bills.

**6. `app.js`** — Three fixes:
- `saveBill()` now includes `paidAmount` in the POST/PUT payload
- `editBill()` now populates the "Amount Paid" input with the saved value
- `renderBills()` shows new **Paid (Rs.)** and **Pending (Rs.)** columns with colour coding

**7. `index.html`** — Bills table header updated with Paid and Pending columns.

**8. `DataSeeder.java`** — `makeBill()` now sets `paidAmount` automatically.
